/******************************************************************************************************
 * Mod Log
 * Version          Author             Date           Description
 * Initial Version  Pratyusha Ghosh    27 Jul, 2009   Common js functions called from the wrapper
 * 2.0              Pratyusha Ghosh    12 Oct, 2009   R942.1: 
 *                                                    1. #557 - Added timer() functionality for
 *                                                    Header flyout delay implementation.
 *                                                    2. Updated onLoadURL() for 'Email this Page'.
 *                                                    3. Added method searchFocus() for default focus
 *                                                    on 'Search' text box in header.
 * 3.0              Pratyusha Ghosh    03 Nov, 2009   R1011: Handled on-load search overlay expose 
 *                                                    in microsites
******************************************************************************************************/

/* Start: Site-redsign - Added */
function formLink(changeLocale) {
    var currentUrl = window.location.href;
    var urlSplit = currentUrl.split('/');
    var http=urlSplit[0];
    var locale=urlSplit[3];
    if (locale != "") {
        var changedUrl=currentUrl.replace(locale, changeLocale);
        location.replace(changedUrl);
    } else {
        location.href=currentUrl + changeLocale;
    }
}
function loadProductList(varCat, varSubcat, varLocale, formName) {
    var url;
    var period = new Array('14', '21', '28', '35', '30', '90', '180', '365');

    if((varCat != "") && (varSubcat != "")) {
        for (i=0;i<8;i++) {
            if(document.getElementById(formName).monthselect.value == period[i]){
                url='/'+varLocale+'/products/'+varCat+'/'+varSubcat+'/'+period[i]+'/newProd.html';
            }
        }
    } else if(varCat != "") {
        for (i=0;i<8;i++) {
            if(document.getElementById(formName).monthselect.value== period[i]){
                url='/'+varLocale+'/products/'+varCat+'/'+period[i]+'/newProd.html';
            }
        }
        } else {
        for (i=0;i<8;i++) {                 
            if(document.getElementById(formName).monthselect.value == period[i]){          
                url='/'+varLocale+'/products/'+period[i]+'/allNewProd.html';        
            }
        }
    }
    location.href=url;
}
function printTheMainPage() {
    window.print()
}
function printPopupPage() {
    window.print()
}
function onLoadURL(){
	/* Parent page link to be opened */
	var currentUrl = window.opener.location;
	var urlDiv = document.getElementById('theEmaiLlink');
    urlDiv.innerHTML = currentUrl;
}
/* End: Site-redsign */
/* START: R942.1: #557 - Header flyout delay */ 
//Modified for Microsites Integration 
var aaActiveCss = {'top':'auto','left':'-145px'}
//End: Modification for Microsites Integration
var myAnalogActiveCss = {'top':'auto','left':'-150px'}
function timer() {
    this.timeout = 500; //timeout in milliseconds. To be set as per the desired delay. 
    var t;
    this.activeCss = {'top':'auto','left':'0'}
    this.inactiveCss = {'left':'-999em'}
    this.domObj = null;
    
    /****** Interfacing Methods ******/
    this.cleartimer=cleartimer;
    this.timerOn=timerOn;
}
//Turns ON the timer
function timerOn(tab,cssObj) {
    this.domObj = $(tab);
    if (cssObj != null && typeof cssObj != "undefined") {
        this.activeCss = cssObj;
    }
    //Closure variables. Required to support parameter passing to setTimeout() in IE
    var dObj =  this.domObj;
    var style = this.activeCss;
    this.t = setTimeout(function(){dObj.css(style);dObj=null;dObj=null;},this.timeout);
}
//Turns OFF the timer
function cleartimer() {
    clearTimeout(this.t);
    this.domObj.css(this.inactiveCss);
}
/* R942.1: Added as part of site performance and critical changes fixes */
function searchFocus() {
    $("form#searchform2 #searchbox2").focus();
}
$(document).ready(function () {
    // The below code will execute only for non-IE6 browsers
    if (!($.browser.msie && parseInt($.browser.version) <= 6)) {
        var primaryNav = $("div#primary_nav");
        if (primaryNav != null && primaryNav.length > 0) {
		    //Initializing the timers for the header tabs
		    var pTimer = new timer();
		    var rTimer = new timer();
		    var apTimer = new timer();
		    var aaTimer = new timer();
		    var myanalogTimer = new timer();
		    
		    //Binding the event handlers with the timer for each header tab
		    $("ul#mega li#products_" + language).bind("mouseenter", function(){
		        pTimer.timerOn($("#product_mega"));
		    }).bind("mouseleave", function(){
		        pTimer.cleartimer();
		    });
		    $("ul#mega li#resources1_" + language).bind("mouseenter", function(){
		        rTimer.timerOn($("#resources_mega"));
		    }).bind("mouseleave", function(){
		        rTimer.cleartimer();
		    });
		    //Added for Microsites Integration
		    $("ul#mega li#applications_" + language).bind("mouseenter", function(){
		        apTimer.timerOn($("#application_mega"));
		    }).bind("mouseleave", function(){
		        apTimer.cleartimer();
		    });
		    //End: Addition for Microsites Integration
		    $("ul#mega li#about_" + language).bind("mouseenter", function(){
		        aaTimer.timerOn($("#about_adi_mega"),aaActiveCss);
		    }).bind("mouseleave", function(){
		        aaTimer.cleartimer();
		    });
		    $("ul#mega li#my_analog").bind("mouseenter", function(){
		        myanalogTimer.timerOn($("#my_analog_mega"),myAnalogActiveCss);
		    }).bind("mouseleave", function(){
		        myanalogTimer.cleartimer();
		    });
        }
    }
    // On-load focus in the search text box.
    //  R1011: Modified to handle on-load search overlay expose in microsites
    if (document.getElementById('search_drop') == null) {
        searchFocus();
    }
});
/* END: R942.1 */

/*START: 15237 - SEARCH URL FORMAT CHANGE */
function validateSearchKeyword(formName, searchbox,locale){
	var searchWord = document.getElementById(searchbox).value;
	var autonomyUrl = document.getElementById('autonomyUri').value;
	var analogUrl = document.getElementById('analogUri').value;
	
	searchWord = jQuery.trim(searchWord);
	var index = searchWord.indexOf(" ");
	var regMatch = searchWord.match(/^[-a-zA-Z0-9]+$/);
	
	if((index != -1 && index != searchWord.length -1) || regMatch == null){
		searchWord = encodeURIComponent(searchWord);
		//alert(autonomyUrl + "?query=" + searchWord + "&local=" + locale);
		formName.action = autonomyUrl + "?query=" + searchWord + "&local=" + locale;
	}else{
		//alert(analogUrl + locale + "/" + searchWord + "/productSearch.html");
		location.href = analogUrl + locale + "/" + searchWord + "/productSearch.html";
		return false;
	}
	formName.submit();
	return true;
}
/*END: 15237 - SEARCH URL FORMAT CHANGE */