/***************************************************************************
  FILENAME:				desing_tables.js
  DESCRIPTION:			This include file contains all of the necessary 
						functions to build the dynamic response/order list.
			

  CREATION DATE:		11/15/2003
  INITIAL AUTHOR: 		Jay Harris

  History:

  11/15/2003  Initial Version

  Copyright (C) 2003 Molecular
  Molecular Confidential
***************************************************************************/
var butterworthArray = new Array(10);

for(var i=0;i<=10;i++){
	butterworthArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		butterworthArray[i][j] = new Array(1);
}

butterworthArray[2][1][0] = 1.0000;
butterworthArray[2][1][1] = 0.7071;
butterworthArray[3][1][0] = 1.0000;
butterworthArray[3][1][1] = 1.0000;
butterworthArray[3][2][0] = 1.0000;
butterworthArray[4][1][0] = 1.0000;
butterworthArray[4][1][1] = 0.5412;
butterworthArray[4][2][0] = 1.0000;
butterworthArray[4][2][1] = 1.3065;
butterworthArray[5][1][0] = 1.0000;
butterworthArray[5][1][1] = 0.6180;
butterworthArray[5][2][0] = 1.0000;
butterworthArray[5][2][1] = 1.6182;
butterworthArray[5][3][0] = 1.0000;
butterworthArray[6][1][0] = 1.0000;
butterworthArray[6][1][1] = 0.5176;
butterworthArray[6][2][0] = 1.0000;
butterworthArray[6][2][1] = 0.7071;
butterworthArray[6][3][0] = 1.0000;
butterworthArray[6][3][1] = 1.9319;
butterworthArray[7][1][0] = 1.0000;
butterworthArray[7][1][1] = 0.5550;
butterworthArray[7][2][0] = 1.0000;
butterworthArray[7][2][1] = 0.8019;
butterworthArray[7][3][0] = 1.0000;
butterworthArray[7][3][1] = 2.2471;
butterworthArray[7][4][0] = 1.0000;
butterworthArray[8][1][0] = 1.0000;
butterworthArray[8][1][1] = 0.5098;
butterworthArray[8][2][0] = 1.0000;
butterworthArray[8][2][1] = 0.6013;
butterworthArray[8][3][0] = 1.0000;
butterworthArray[8][3][1] = 0.9000;
butterworthArray[8][4][0] = 1.0000;
butterworthArray[8][4][1] = 2.5628;
butterworthArray[9][1][0] = 1.0000;
butterworthArray[9][1][1] = 0.5321;
butterworthArray[9][2][0] = 1.0000;
butterworthArray[9][2][1] = 0.6527;
butterworthArray[9][3][0] = 1.0000;
butterworthArray[9][3][1] = 1.0000;
butterworthArray[9][4][0] = 1.0000;
butterworthArray[9][4][1] = 2.8785;
butterworthArray[9][5][0] = 1.0000;
butterworthArray[10][1][0] = 1.0000;
butterworthArray[10][1][1] = 0.5062;
butterworthArray[10][2][0] = 1.0000;
butterworthArray[10][2][1] = 0.5612;
butterworthArray[10][3][0] = 1.0000;
butterworthArray[10][3][1] = 0.7071;
butterworthArray[10][4][0] = 1.0000;
butterworthArray[10][4][1] = 1.1013;
butterworthArray[10][5][0] = 1.0000;
butterworthArray[10][5][1] = 3.1970;


var pt1chebyshevArray = new Array(10);

for(var i=0;i<=10;i++){
	pt1chebyshevArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt1chebyshevArray[i][j] = new Array(1);
}

pt1chebyshevArray[2][1][0] = 0.9368;
pt1chebyshevArray[2][1][1] = 0.7673;
pt1chebyshevArray[3][1][0] = 0.9359;
pt1chebyshevArray[3][1][1] = 1.3408;
pt1chebyshevArray[3][2][0] = 0.6970;
pt1chebyshevArray[4][1][0] = 0.9507;
pt1chebyshevArray[4][1][1] = 2.1834;
pt1chebyshevArray[4][2][0] = 0.6506;
pt1chebyshevArray[4][2][1] = 0.6188;
pt1chebyshevArray[5][1][0] = 0.7027;
pt1chebyshevArray[5][1][1] = 0.9145;
pt1chebyshevArray[5][2][0] = 0.9634;
pt1chebyshevArray[5][2][1] = 3.2812;
pt1chebyshevArray[5][3][0] = 0.4749;
pt1chebyshevArray[6][1][0] = 0.4695;
pt1chebyshevArray[6][1][1] = 0.5995;
pt1chebyshevArray[6][2][0] = 0.7636;
pt1chebyshevArray[6][2][1] = 1.3316;
pt1chebyshevArray[6][3][0] = 0.9724;
pt1chebyshevArray[6][3][1] = 4.6348;
pt1chebyshevArray[7][1][0] = 0.5380;
pt1chebyshevArray[7][1][1] = 0.8464;
pt1chebyshevArray[7][2][0] = 0.8126;
pt1chebyshevArray[7][2][1] = 1.8469;
pt1chebyshevArray[7][3][0] = 0.9787;
pt1chebyshevArray[7][3][1] = 6.2335;
pt1chebyshevArray[7][4][0] = 0.3528;
pt1chebyshevArray[8][1][0] = 0.3628;
pt1chebyshevArray[8][1][1] = 0.5932;
pt1chebyshevArray[8][2][0] = 0.6106;
pt1chebyshevArray[8][2][1] = 1.2073;
pt1chebyshevArray[8][3][0] = 0.8497;
pt1chebyshevArray[8][3][1] = 2.4531;
pt1chebyshevArray[8][4][0] = 0.9831;
pt1chebyshevArray[8][4][1] = 8.0819;
pt1chebyshevArray[9][1][0] = 0.4310;
pt1chebyshevArray[9][1][1] = 0.8219;
pt1chebyshevArray[9][2][0] = 0.6776;
pt1chebyshevArray[9][2][1] = 1.5854;
pt1chebyshevArray[9][3][0] = 0.8775;
pt1chebyshevArray[9][3][1] = 3.1450;
pt1chebyshevArray[9][4][0] = 0.9864;
pt1chebyshevArray[9][4][1] = 10.1795;
pt1chebyshevArray[9][5][0] = 0.2790;
pt1chebyshevArray[10][1][0] = 0.2943;
pt1chebyshevArray[10][1][1] = 0.5902;
pt1chebyshevArray[10][2][0] = 0.5067;
pt1chebyshevArray[10][2][1] = 1.1266;
pt1chebyshevArray[10][3][0] = 0.7295;
pt1chebyshevArray[10][3][1] = 2.0434;
pt1chebyshevArray[10][4][0] = 0.8986;
pt1chebyshevArray[10][4][1] = 3.9208;
pt1chebyshevArray[10][5][0] = 0.9888;
pt1chebyshevArray[10][5][1] = 12.5163;

var pt10chebyshevArray = new Array(10);

for(var i=0;i<=10;i++){
	pt10chebyshevArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt10chebyshevArray[i][j] = new Array(1);
}

pt10chebyshevArray[2][1][0] = 0.8623;
pt10chebyshevArray[2][1][1] = 0.9564;
pt10chebyshevArray[3][1][0] = 0.9106;
pt10chebyshevArray[3][1][1] = 2.0173;
pt10chebyshevArray[3][2][0] = 0.4513;
pt10chebyshevArray[4][1][0] = 0.5019;
pt10chebyshevArray[4][1][1] = 0.7845;
pt10chebyshevArray[4][2][0] = 0.9433;
pt10chebyshevArray[4][2][1] = 3.5594;
pt10chebyshevArray[5][1][0] = 0.6337;
pt10chebyshevArray[5][1][1] = 1.3988;
pt10chebyshevArray[5][2][0] = 0.9614;
pt10chebyshevArray[5][2][1] = 5.5559;
pt10chebyshevArray[5][3][0] = 0.2800;
pt10chebyshevArray[6][1][0] = 0.3451;
pt10chebyshevArray[6][1][1] = 0.7608;
pt10chebyshevArray[6][2][0] = 0.7273;
pt10chebyshevArray[6][2][1] = 2.3462;
pt10chebyshevArray[6][3][0] = 0.9726;
pt10chebyshevArray[6][3][1] = 8.0036;
pt10chebyshevArray[7][1][0] = 0.4719;
pt10chebyshevArray[7][1][1] = 1.2971;
pt10chebyshevArray[7][2][0] = 0.7946;
pt10chebyshevArray[7][2][1] = 3.1558;
pt10chebyshevArray[7][3][0] = 0.9795;
pt10chebyshevArray[7][3][1] = 10.8982;
pt10chebyshevArray[7][4][0] = 0.2019;
pt10chebyshevArray[8][1][0] = 0.2616;
pt10chebyshevArray[8][1][1] = 0.7530;
pt10chebyshevArray[8][2][0] = 0.5762;
pt10chebyshevArray[8][2][1] = 1.9560;
pt10chebyshevArray[8][3][0] = 0.8395;
pt10chebyshevArray[8][3][1] = 4.2657;
pt10chebyshevArray[8][4][0] = 0.9842;
pt10chebyshevArray[8][4][1] = 14.2391;
pt10chebyshevArray[9][1][0] = 0.3734;
pt10chebyshevArray[9][1][1] = 1.2597;
pt10chebyshevArray[9][2][0] = 0.6554;
pt10chebyshevArray[9][2][1] = 2.7129;
pt10chebyshevArray[9][3][0] = 0.8715;
pt10chebyshevArray[9][3][1] = 5.5268;
pt10chebyshevArray[9][4][0] = 0.9873;
pt10chebyshevArray[9][4][1] = 18.0226;
pt10chebyshevArray[9][5][0] = 0.1577;
pt10chebyshevArray[10][1][0] = 0.2103;
pt10chebyshevArray[10][1][1] = 0.7496;
pt10chebyshevArray[10][2][0] = 0.4721;
pt10chebyshevArray[10][2][1] = 1.8645;
pt10chebyshevArray[10][3][0] = 0.7155;
pt10chebyshevArray[10][3][1] = 3.5597;
pt10chebyshevArray[10][4][0] = 0.8949;
pt10chebyshevArray[10][4][1] = 6.9374;
pt10chebyshevArray[10][5][0] = 0.9897;
pt10chebyshevArray[10][5][1] = 22.2916;

var pt01chebyshevArray = new Array(10);

for(var i=0;i<=10;i++){
	pt01chebyshevArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt01chebyshevArray[i][j] = new Array(1);
}

pt01chebyshevArray[2][1][0] = 0.9774;
pt01chebyshevArray[2][1][1] = 0.7247;
pt01chebyshevArray[3][1][0] = 0.9642;
pt01chebyshevArray[3][1][1] = 1.1389;
pt01chebyshevArray[3][2][0] = 0.8467;
pt01chebyshevArray[4][1][0] = 0.7770;
pt01chebyshevArray[4][1][1] = 0.5746;
pt01chebyshevArray[4][2][0] = 0.9656;
pt01chebyshevArray[4][2][1] = 1.7237;
pt01chebyshevArray[5][1][0] = 0.7796;
pt01chebyshevArray[5][1][1] = 0.7613;
pt01chebyshevArray[5][2][0] = 0.9711;
pt01chebyshevArray[5][2][1] = 2.4824;
pt01chebyshevArray[5][3][0] = 0.6328;
pt01chebyshevArray[6][1][0] = 0.5930;
pt01chebyshevArray[6][1][1] = 0.5557;
pt01chebyshevArray[6][2][0] = 0.8079;
pt01chebyshevArray[6][2][1] = 1.0342;
pt01chebyshevArray[6][3][0] = 0.9765;
pt01chebyshevArray[6][3][1] = 3.4144;
pt01chebyshevArray[7][1][0] = 0.6175;
pt01chebyshevArray[7][1][1] = 0.7028;
pt01chebyshevArray[7][2][0] = 0.8389;
pt01chebyshevArray[7][2][1] = 1.3798;
pt01chebyshevArray[7][3][0] = 0.9810;
pt01chebyshevArray[7][3][1] = 4.5208;
pt01chebyshevArray[7][4][0] = 0.4876;
pt01chebyshevArray[8][1][0] = 0.4693;
pt01chebyshevArray[8][1][1] = 0.5498;
pt01chebyshevArray[8][2][0] = 0.6396;
pt01chebyshevArray[8][2][1] = 1.0094;
pt01chebyshevArray[8][3][0] = 0.8659;
pt01chebyshevArray[8][3][1] = 1.7906;
pt01chebyshevArray[8][4][0] = 0.9845;
pt01chebyshevArray[8][4][1] = 5.7978;
pt01chebyshevArray[9][1][0] = 0.5028;
pt01chebyshevArray[9][1][1] = 0.6821;
pt01chebyshevArray[9][2][0] = 0.7096;
pt01chebyshevArray[9][2][1] = 1.1807;
pt01chebyshevArray[9][3][0] = 0.8880;
pt01chebyshevArray[9][3][1] = 2.2642;
pt01chebyshevArray[9][4][0] = 0.9872;
pt01chebyshevArray[9][4][1] = 7.2478;
pt01chebyshevArray[9][5][0] = 0.3923;
pt01chebyshevArray[10][1][0] = 0.3854;
pt01chebyshevArray[10][1][1] = 0.5471;
pt01chebyshevArray[10][2][0] = 0.5542;
pt01chebyshevArray[10][2][1] = 0.8719;
pt01chebyshevArray[10][3][0] = 0.7507;
pt01chebyshevArray[10][3][1] = 1.4884;
pt01chebyshevArray[10][4][0] = 0.9056;
pt01chebyshevArray[10][4][1] = 2.7968;
pt01chebyshevArray[10][5][0] = 0.9893;
pt01chebyshevArray[10][5][1] = 8.8645;

var pt25chebyshevArray = new Array(10);

for(var i=0;i<=10;i++){
	pt25chebyshevArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt25chebyshevArray[i][j] = new Array(1);
}

pt25chebyshevArray[2][1][0] = 0.9098;
pt25chebyshevArray[2][1][1] = 0.8093;
pt25chebyshevArray[3][1][0] = 0.9234;
pt25chebyshevArray[3][1][1] = 1.5079;
pt25chebyshevArray[3][2][0] = 0.6124;
pt25chebyshevArray[4][1][0] = 0.5916;
pt25chebyshevArray[4][1][1] = 0.6572;
pt25chebyshevArray[4][2][0] = 0.9458;
pt25chebyshevArray[4][2][1] = 2.5356;
pt25chebyshevArray[5][1][0] = 0.6727;
pt25chebyshevArray[5][1][1] = 1.0359;
pt25chebyshevArray[5][2][0] = 0.9613;
pt25chebyshevArray[5][2][1] = 3.8763;
pt25chebyshevArray[5][3][0] = 0.4013;
pt25chebyshevArray[6][1][0] = 0.4184;
pt25chebyshevArray[6][1][1] = 0.6371;
pt25chebyshevArray[6][2][0] = 0.7480;
pt25chebyshevArray[6][2][1] = 1.5557;
pt25chebyshevArray[6][3][0] = 0.9715;
pt25chebyshevArray[6][3][1] = 5.5205;
pt25chebyshevArray[7][1][0] = 0.5090;
pt25chebyshevArray[7][1][1] = 0.9596;
pt25chebyshevArray[7][2][0] = 0.8040;
pt25chebyshevArray[7][2][1] = 2.1908;
pt25chebyshevArray[7][3][0] = 0.9783;
pt25chebyshevArray[7][3][1] = 7.4679;
pt25chebyshevArray[7][4][0] = 0.2944;
pt25chebyshevArray[8][1][0] = 0.3206;
pt25chebyshevArray[8][1][1] = 0.6304;
pt25chebyshevArray[8][2][0] = 0.5964;
pt25chebyshevArray[8][2][1] = 1.3832;
pt25chebyshevArray[8][3][0] = 0.8447;
pt25chebyshevArray[8][3][1] = 2.9309;
pt25chebyshevArray[8][4][0] = 0.9830;
pt25chebyshevArray[8][4][1] = 9.7173;
pt25chebyshevArray[9][1][0] = 0.4056;
pt25chebyshevArray[9][1][1] = 0.9320;
pt25chebyshevArray[9][2][0] = 0.6673;
pt25chebyshevArray[9][2][1] = 1.8808;
pt25chebyshevArray[9][3][0] = 0.8744;
pt25chebyshevArray[9][3][1] = 3.7755;
pt25chebyshevArray[9][4][0] = 0.9864;
pt25chebyshevArray[9][4][1] = 12.2659;
pt25chebyshevArray[9][5][0] = 0.2315;
pt25chebyshevArray[10][1][0] = 0.2591;
pt25chebyshevArray[10][1][1] = 0.6274;
pt25chebyshevArray[10][2][0] = 0.4910;
pt25chebyshevArray[10][2][1] = 1.3178;
pt25chebyshevArray[10][3][0] = 0.7228;
pt25chebyshevArray[10][3][1] = 2.4451;
pt25chebyshevArray[10][4][0] = 0.8965;
pt25chebyshevArray[10][4][1] = 4.7236;
pt25chebyshevArray[10][5][0] = 0.9888;
pt25chebyshevArray[10][5][1] = 15.1199;

var pt5chebyshevArray = new Array(10);

for(var i=0;i<=10;i++){
	pt5chebyshevArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt5chebyshevArray[i][j] = new Array(1);
}

pt5chebyshevArray[2][1][0] = 1.2314;
pt5chebyshevArray[2][1][1] = 0.8638;
pt5chebyshevArray[3][1][0] = 1.0688;
pt5chebyshevArray[3][1][1] = 1.7061;
pt5chebyshevArray[3][2][0] = 0.6265;
pt5chebyshevArray[4][1][0] = 0.5969;
pt5chebyshevArray[4][1][1] = 0.7051;
pt5chebyshevArray[4][2][0] = 1.0313;
pt5chebyshevArray[4][2][1] = 2.9391;
pt5chebyshevArray[5][1][0] = 0.6905;
pt5chebyshevArray[5][1][1] = 1.1779;
pt5chebyshevArray[5][2][0] = 1.0178;
pt5chebyshevArray[5][2][1] = 4.5451;
pt5chebyshevArray[5][3][0] = 0.3623;
pt5chebyshevArray[6][1][0] = 0.3963;
pt5chebyshevArray[6][1][1] = 0.6836;
pt5chebyshevArray[6][2][0] = 0.7680;
pt5chebyshevArray[6][2][1] = 1.8109;
pt5chebyshevArray[6][3][0] = 1.0114;
pt5chebyshevArray[6][3][1] = 6.5119;
pt5chebyshevArray[7][1][0] = 0.5040;
pt5chebyshevArray[7][1][1] = 1.0916;
pt5chebyshevArray[7][2][0] = 0.8228;
pt5chebyshevArray[7][2][1] = 2.5767;
pt5chebyshevArray[7][3][0] = 1.0081;
pt5chebyshevArray[7][3][1] = 8.8487;
pt5chebyshevArray[7][4][0] = 0.2562;
pt5chebyshevArray[8][1][0] = 0.2968;
pt5chebyshevArray[8][1][1] = 0.6767;
pt5chebyshevArray[8][2][0] = 0.5989;
pt5chebyshevArray[8][2][1] = 1.6109;
pt5chebyshevArray[8][3][0] = 0.8610;
pt5chebyshevArray[8][3][1] = 3.4662;
pt5chebyshevArray[8][4][0] = 1.0060;
pt5chebyshevArray[8][4][1] = 11.5305;
pt5chebyshevArray[9][1][0] = 0.3954;
pt5chebyshevArray[9][1][1] = 1.0605;
pt5chebyshevArray[9][2][0] = 0.6727;
pt5chebyshevArray[9][2][1] = 2.2126;
pt5chebyshevArray[9][3][0] = 0.8884;
pt5chebyshevArray[9][3][1] = 4.4779;
pt5chebyshevArray[9][4][0] = 1.0046;
pt5chebyshevArray[9][4][1] = 14.5829;
pt5chebyshevArray[9][5][0] = 0.1984;
pt5chebyshevArray[10][1][0] = 0.2338;
pt5chebyshevArray[10][1][1] = 0.6734;
pt5chebyshevArray[10][2][0] = 0.4807;
pt5chebyshevArray[10][2][1] = 1.5349;
pt5chebyshevArray[10][3][0] = 0.7186;
pt5chebyshevArray[10][3][1] = 2.8907;
pt5chebyshevArray[10][4][0] = 0.8955;
pt5chebyshevArray[10][4][1] = 5.6107;
pt5chebyshevArray[10][5][0] = 0.9891;
pt5chebyshevArray[10][5][1] = 17.9833;

var besselArray = new Array(10);
for(var i=0;i<=10;i++){
	besselArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		besselArray[i][j] = new Array(1);
}

besselArray[2][1][0] = 1.2754;
besselArray[2][1][1] = 0.5771;
besselArray[3][1][0] = 1.4524;
besselArray[3][1][1] = 0.6910;
besselArray[3][2][0] = 1.3270;
besselArray[4][1][0] = 1.4192;
besselArray[4][1][1] = 0.5219;
besselArray[4][2][0] = 1.5912;
besselArray[4][2][1] = 0.8055;
besselArray[5][1][0] = 1.5611;
besselArray[5][1][1] = 0.5635;
besselArray[5][2][0] = 1.7607;
besselArray[5][2][1] = 0.9165;
besselArray[5][3][0] = 1.5069;
besselArray[6][1][0] = 1.6060;
besselArray[6][1][1] = 0.5103;
besselArray[6][2][0] = 1.6913;
besselArray[6][2][1] = 0.6112;
besselArray[6][3][0] = 1.9071;
besselArray[6][3][1] = 1.0234;
besselArray[7][1][0] = 1.7174;
besselArray[7][1][1] = 0.5324;
besselArray[7][2][0] = 1.8235;
besselArray[7][2][1] = 0.6608;
besselArray[7][3][0] = 2.0507;
besselArray[7][3][1] = 1.1262;
besselArray[7][4][0] = 1.6853;
besselArray[8][1][0] = 1.7838;
besselArray[8][1][1] = 0.5060;
besselArray[8][2][0] = 2.1953;
besselArray[8][2][1] = 1.2258;
besselArray[8][3][0] = 1.9591;
besselArray[8][3][1] = 0.7109;
besselArray[8][4][0] = 1.8378;
besselArray[8][4][1] = 0.5597;
besselArray[9][1][0] = 1.8794;
besselArray[9][1][1] = 0.5197;
besselArray[9][2][0] = 1.9488;
besselArray[9][2][1] = 0.5894;
besselArray[9][3][0] = 2.0815;
besselArray[9][3][1] = 0.7606;
besselArray[9][4][0] = 2.3235;
besselArray[9][4][1] = 1.3220;
besselArray[9][5][0] = 1.8575;
besselArray[10][1][0] = 1.9490;
besselArray[10][1][1] = 0.5040;
besselArray[10][2][0] = 1.9870;
besselArray[10][2][1] = 0.5380;
besselArray[10][3][0] = 2.0678;
besselArray[10][3][1] = 0.6205;
besselArray[10][4][0] = 2.2110;
besselArray[10][4][1] = 0.8100;
besselArray[10][5][0] = 2.4580;
besselArray[10][5][1] = 1.4150;

var pt05equirppleArray = new Array(10);
for(var i=0;i<=10;i++){
	pt05equirppleArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt05equirppleArray[i][j] = new Array(1);
}

pt05equirppleArray[2][1][0] = 1.2098;
pt05equirppleArray[2][1][1] = 0.5997;
pt05equirppleArray[3][1][0] = 1.3710;
pt05equirppleArray[3][1][1] = 0.8026;
pt05equirppleArray[3][2][0] = 1.0459;
pt05equirppleArray[4][1][0] = 1.0753;
pt05equirppleArray[4][1][1] = 0.5573;
pt05equirppleArray[4][2][0] = 1.5865;
pt05equirppleArray[4][2][1] = 1.0650;
pt05equirppleArray[5][1][0] = 1.2480;
pt05equirppleArray[5][1][1] = 0.6999;
pt05equirppleArray[5][2][0] = 1.8363;
pt05equirppleArray[5][2][1] = 1.3641;
pt05equirppleArray[5][3][0] = 0.9430;
pt05equirppleArray[6][1][0] = 0.9807;
pt05equirppleArray[6][1][1] = 0.5507;
pt05equirppleArray[6][2][0] = 1.4701;
pt05equirppleArray[6][2][1] = 0.8928;
pt05equirppleArray[6][3][0] = 2.0743;
pt05equirppleArray[6][3][1] = 1.6859;
pt05equirppleArray[7][1][0] = 1.1475;
pt05equirppleArray[7][1][1] = 0.6810;
pt05equirppleArray[7][2][0] = 1.7177;
pt05equirppleArray[7][2][1] = 1.1143;
pt05equirppleArray[7][3][0] = 2.3175;
pt05equirppleArray[7][3][1] = 2.0233;
pt05equirppleArray[7][4][0] = 0.8615;
pt05equirppleArray[8][1][0] = 0.8996;
pt05equirppleArray[8][1][1] = 0.5489;
pt05equirppleArray[8][2][0] = 1.3604;
pt05equirppleArray[8][2][1] = 0.8578;
pt05equirppleArray[8][3][0] = 1.9516;
pt05equirppleArray[8][3][1] = 1.3528;
pt05equirppleArray[8][4][0] = 2.5330;
pt05equirppleArray[8][4][1] = 2.3713;
pt05equirppleArray[9][1][0] = 1.0604;
pt05equirppleArray[9][1][1] = 0.6751;
pt05equirppleArray[9][2][0] = 1.6020;
pt05equirppleArray[9][2][1] = 1.0602;
pt05equirppleArray[9][3][0] = 2.1950;
pt05equirppleArray[9][3][1] = 1.6024;
pt05equirppleArray[9][4][0] = 2.7601;
pt05equirppleArray[9][4][1] = 2.7274;
pt05equirppleArray[9][5][0] = 0.7983;
pt05equirppleArray[10][1][0] = 0.8324;
pt05equirppleArray[10][1][1] = 0.5482;
pt05equirppleArray[10][2][0] = 1.2637;
pt05equirppleArray[10][2][1] = 0.8462;
pt05equirppleArray[10][3][0] = 1.8295;
pt05equirppleArray[10][3][1] = 1.2778;
pt05equirppleArray[10][4][0] = 2.4085;
pt05equirppleArray[10][4][1] = 1.8598;
pt05equirppleArray[10][5][0] = 2.9517;
pt05equirppleArray[10][5][1] = 3.0895;

var pt5equirppleArray = new Array(10);
for(var i=0;i<=10;i++){
	pt5equirppleArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		pt5equirppleArray[i][j] = new Array(1);
}

pt5equirppleArray[2][1][0] = 1.1069;
pt5equirppleArray[2][1][1] = 0.6443;
pt5equirppleArray[3][1][0] = 1.3292;
pt5equirppleArray[3][1][1] = 0.9536;
pt5equirppleArray[3][2][0] = 0.8257;
pt5equirppleArray[4][1][0] = 0.9045;
pt5equirppleArray[4][1][1] = 0.6072;
pt5equirppleArray[4][2][0] = 1.6154;
pt5equirppleArray[4][2][1] = 1.3379;
pt5equirppleArray[5][1][0] = 1.1588;
pt5equirppleArray[5][1][1] = 0.8552;
pt5equirppleArray[5][2][0] = 1.9041;
pt5equirppleArray[5][2][1] = 1.7592;
pt5equirppleArray[5][3][0] = 0.7056;
pt5equirppleArray[6][1][0] = 0.7850;
pt5equirppleArray[6][1][1] = 0.6021;
pt5equirppleArray[6][2][0] = 1.4355;
pt5equirppleArray[6][2][1] = 1.1639;
pt5equirppleArray[6][3][0] = 2.1545;
pt5equirppleArray[6][3][1] = 2.2016;
pt5equirppleArray[7][1][0] = 1.0385;
pt5equirppleArray[7][1][1] = 0.8388;
pt5equirppleArray[7][2][0] = 1.7453;
pt5equirppleArray[7][2][1] = 1.5004;
pt5equirppleArray[7][3][0] = 2.4431;
pt5equirppleArray[7][3][1] = 2.6567;
pt5equirppleArray[7][4][0] = 0.6283;
pt5equirppleArray[8][1][0] = 0.6958;
pt5equirppleArray[8][1][1] = 0.6007;
pt5equirppleArray[8][2][0] = 1.2824;
pt5equirppleArray[8][2][1] = 1.1319;
pt5equirppleArray[8][3][0] = 1.9643;
pt5equirppleArray[8][3][1] = 1.8521;
pt5equirppleArray[8][4][0] = 2.6112;
pt5equirppleArray[8][4][1] = 3.1475;
pt5equirppleArray[9][1][0] = 0.9489;
pt5equirppleArray[9][1][1] = 0.8341;
pt5equirppleArray[9][2][0] = 1.6076;
pt5equirppleArray[9][2][1] = 1.4496;
pt5equirppleArray[9][3][0] = 2.2922;
pt5equirppleArray[9][3][1] = 2.2130;
pt5equirppleArray[9][4][0] = 2.9313;
pt5equirppleArray[9][4][1] = 3.5923;
pt5equirppleArray[9][5][0] = 0.5728;
pt5equirppleArray[10][1][0] = 0.6302;
pt5equirppleArray[10][1][1] = 0.6003;
pt5equirppleArray[10][2][0] = 1.1650;
pt5equirppleArray[10][2][1] = 1.1217;
pt5equirppleArray[10][3][0] = 1.7988;
pt5equirppleArray[10][3][1] = 1.7806;
pt5equirppleArray[10][4][0] = 2.4311;
pt5equirppleArray[10][4][1] = 2.5802;
pt5equirppleArray[10][5][0] = 3.0169;
pt5equirppleArray[10][5][1] = 4.0681;

var db6GaussianArray = new Array(10);
for(var i=0;i<=10;i++){
	db6GaussianArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		db6GaussianArray[i][j] = new Array(1);
}

db6GaussianArray[3][1][0] = 1.5549;
db6GaussianArray[3][1][1] = 0.8080;
db6GaussianArray[3][2][0] = 1.0994;
db6GaussianArray[4][1][0] = 0.9399;
db6GaussianArray[4][1][1] = 0.5919;
db6GaussianArray[4][2][0] = 1.6647;
db6GaussianArray[4][2][1] = 1.3203;
db6GaussianArray[5][1][0] = 1.0317;
db6GaussianArray[5][1][1] = 0.8334;
db6GaussianArray[5][2][0] = 1.6087;
db6GaussianArray[5][2][1] = 2.2600;
db6GaussianArray[5][3][0] = 0.6650;
db6GaussianArray[6][1][0] = 0.6426;
db6GaussianArray[6][1][1] = 0.5914;
db6GaussianArray[6][2][0] = 1.1029;
db6GaussianArray[6][2][1] = 1.1804;
db6GaussianArray[6][3][0] = 1.5227;
db6GaussianArray[6][3][1] = 3.4545;
db6GaussianArray[7][1][0] = 0.7494;
db6GaussianArray[7][1][1] = 0.8182;
db6GaussianArray[7][2][0] = 1.1861;
db6GaussianArray[7][2][1] = 1.6253;
db6GaussianArray[7][3][0] = 1.5015;
db6GaussianArray[7][3][1] = 4.9328;
db6GaussianArray[7][4][0] = 0.4828;
db6GaussianArray[8][1][0] = 0.4979;
db6GaussianArray[8][1][1] = 0.5897;
db6GaussianArray[8][2][0] = 0.8616;
db6GaussianArray[8][2][1] = 1.1239;
db6GaussianArray[8][3][0] = 1.2360;
db6GaussianArray[8][3][1] = 2.3076;
db6GaussianArray[8][4][0] = 1.4840;
db6GaussianArray[8][4][1] = 6.6134;
db6GaussianArray[9][1][0] = 0.5985;
db6GaussianArray[9][1][1] = 0.8088;
db6GaussianArray[9][2][0] = 0.9626;
db6GaussianArray[9][2][1] = 1.4901;
db6GaussianArray[9][3][0] = 1.2843;
db6GaussianArray[9][3][1] = 2.7811;
db6GaussianArray[9][4][0] = 1.4765;
db6GaussianArray[9][4][1] = 8.5804;
db6GaussianArray[9][5][0] = 0.3842;
db6GaussianArray[10][1][0] = 0.3983;
db6GaussianArray[10][1][1] = 0.5885;
db6GaussianArray[10][2][0] = 0.6943;
db6GaussianArray[10][2][1] = 1.0972;
db6GaussianArray[10][3][0] = 1.0209;
db6GaussianArray[10][3][1] = 1.9068;
db6GaussianArray[10][4][0] = 1.2878;
db6GaussianArray[10][4][1] = 3.4825;
db6GaussianArray[10][5][0] = 1.4405;
db6GaussianArray[10][5][1] = 10.7401;

var db12GaussianArray = new Array(10);
for(var i=0;i<=10;i++){
	db12GaussianArray[i] = new Array(5);
	for(var j=0;j<=5;j++)
		db12GaussianArray[i][j] = new Array(1);
}

db12GaussianArray[3][1][0] = 1.5352;
db12GaussianArray[3][1][1] = 0.8201;
db12GaussianArray[3][2][0] = 0.9360;
db12GaussianArray[4][1][0] = 1.9363;
db12GaussianArray[4][1][1] = 1.0435;
db12GaussianArray[4][2][0] = 1.0743;
db12GaussianArray[4][2][1] = 0.5844;
db12GaussianArray[5][1][0] = 1.2832;
db12GaussianArray[5][1][1] = 0.7946;
db12GaussianArray[5][2][0] = 2.1746;
db12GaussianArray[5][2][1] = 1.5198;
db12GaussianArray[5][3][0] = 0.8131;
db12GaussianArray[6][1][0] = 0.8243;
db12GaussianArray[6][1][1] = 0.5872;
db12GaussianArray[6][2][0] = 1.4549;
db12GaussianArray[6][2][1] = 1.0911;
db12GaussianArray[6][3][0] = 2.1827;
db12GaussianArray[6][3][1] = 2.4366;
db12GaussianArray[7][1][0] = 0.9860;
db12GaussianArray[7][1][1] = 0.8010;
db12GaussianArray[7][2][0] = 1.6116;
db12GaussianArray[7][2][1] = 1.4689;
db12GaussianArray[7][3][0] = 2.1681;
db12GaussianArray[7][3][1] = 3.7318;
db12GaussianArray[7][4][0] = 0.6291;
db12GaussianArray[8][1][0] = 0.6394;
db12GaussianArray[8][1][1] = 0.5876;
db12GaussianArray[8][2][0] = 1.1226;
db12GaussianArray[8][2][1] = 1.0846;
db12GaussianArray[8][3][0] = 1.6672;
db12GaussianArray[8][3][1] = 1.9260;
db12GaussianArray[8][4][0] = 2.0797;
db12GaussianArray[8][4][1] = 5.2571;
db12GaussianArray[9][1][0] = 0.7934;
db12GaussianArray[9][1][1] = 0.7997;
db12GaussianArray[9][2][0] = 1.2976;
db12GaussianArray[9][2][1] = 1.4203;
db12GaussianArray[9][3][0] = 1.7795;
db12GaussianArray[9][3][1] = 2.4771;
db12GaussianArray[9][4][0] = 2.1056;
db12GaussianArray[9][4][1] = 7.0704;
db12GaussianArray[9][5][0] = 0.5065;
db12GaussianArray[10][1][0] = 0.5327;
db12GaussianArray[10][1][1] = 0.5873;
db12GaussianArray[10][2][0] = 0.9362;
db12GaussianArray[10][2][1] = 1.0756;
db12GaussianArray[10][3][0] = 1.3998;
db12GaussianArray[10][3][1] = 1.8011;
db12GaussianArray[10][4][0] = 1.8072;
db12GaussianArray[10][4][1] = 3.1074;
db12GaussianArray[10][5][0] = 2.0630;
db12GaussianArray[10][5][1] = 9.0802;



function Log10(theNumber){
   return Math.log(theNumber) / Math.log(10)
}



function lowPassTwoPole(Ho, Wo, W, Q, Fo){
	var Alpha = 1 / Q;
 
	var temp = Math.sqrt((Math.pow(Fo, 4)) / (Math.pow(W, 4) + (Math.pow(W, 2) * Math.pow(Fo, 2)) * (Math.pow(Alpha, 2) - 2) + Math.pow(Fo,4)));
	return (20 * Log10(temp));
}

function lowPassSinglePole(Ho, Wo, W, Fo){
	var result = Math.sqrt((Math.pow(Fo,2)) / (Math.pow(W,2) + Math.pow(Fo,2)))
	return 20 * Log10(result)
}


function highPassTwoPole(Ho, Wo, W, Q, FVal){
	var Alpha = 1 / Q
	var result = Math.sqrt((Math.pow(W,4)) / (Math.pow(W,4) + Math.pow(W,2) * Math.pow(FVal,2) * (Math.pow(Alpha,2) - 2) + Math.pow(FVal,4)))

	return 20 * Log10(result)
}

function highPassSinglePole(Ho, Wo, W, FVal){
	var result = Math.sqrt((Math.pow(W,2)) / (Math.pow(W,2) + Math.pow(FVal,2)))
	return 20 * Log10(result)
}


function bandPassTwoPole(Ho, Wo, W, Q){
	var Alpha = 1 / Q
	var result = Math.sqrt((Math.pow(Ho,2) * Math.pow(Wo,2) * Math.pow(Alpha,2) * Math.pow(W,2)) / (Math.pow(W,4) + Math.pow(W,2) * Math.pow(Wo,2) * (Math.pow(Alpha,2) - 2) + Math.pow(Wo,4)))
	return 20 * Log10(result)
}

// CONSTANTS FOR THE RESPONSE ARRAYS
var Q_ID = 1;
var Fo_ID = 0;

function getOrder(responseArray, filterType, Order, Ho, Wo, W){
	var maxSections = Math.ceil(Order/2);
	var result = 0.00;
	


	for(var section=1; section<=maxSections; section++){
		var Q = responseArray[Order][section][Q_ID];
		var Fo = responseArray[Order][section][Fo_ID];
		
		switch(filterType){
			case "Lowpass":

		
				Fo = Wo * Fo

				if(section==maxSections){
					if(Order % 2 == 1)
						result += lowPassSinglePole(Ho, Wo, W, Fo);
					else
						result += lowPassTwoPole(Ho, Wo, W, Q, Fo);
				}
				else
					result += lowPassTwoPole(Ho, Wo, W, Q, Fo);

				break;
			case "Highpass":
			
				FVal = Wo * (1/Fo)

				if(section==maxSections){
					if(Order % 2 == 1)
						result += highPassSinglePole(Ho, Wo, W, FVal);
					else
						result += highPassTwoPole(Ho, Wo, W, Q, FVal);	
				}
				else
					result += highPassTwoPole(Ho, Wo, W, Q, FVal);
					
				break;
			case "Bandpass":
		}

					
	}
	return result
}

function generateFilterResponse(theForm, deg){
	var	itemIndex	= 1;
	var     orderMax = 8;
	var filterType	= theForm.type.value;
	var aMin		= theForm.amin.value;
	var aMax		= theForm.amax.value;
	var fMax		= theForm.fmaxNov.value;
	var W			= ConvertValue(theForm.fs.value, theForm.fs_mag.value, "ST");
//	var Q			= theForm.q.value;
//	var Fo			= theForm.fo.value;
	var Ho			= 1; //theForm.gain.value;
	var okToProceed	= true;
	var browserType = "IE"
	var filterArray = new Array();
	filterArray[0]	=  new Array(1);
	filterArray[0][0] = "< choose response/order >";
	filterArray[0][1] = "";
	

	var name = navigator.appName;
	if (name == "Microsoft Internet Explorer") {
		browserType = "IE";
	}
	else {
		browserType = "Netscape";
	}
	
	if(filterType=='Bandpass')
		var Wo = ConvertValue(theForm.fc1.value, theForm.fc1_mag.value, "ST");
	else
		var Wo = ConvertValue(theForm.fc2.value, theForm.fc2_mag.value, "ST");
	
	// Validate the input values
	if(!validate("amin", theForm.amin.value)) okToProceed = false;
	if(!validate("amax", theForm.amax.value)) okToProceed = false;
	if(!validate("fs", ConvertValue(theForm.fs.value, theForm.fs_mag.value, "ST"))) okToProceed = false;
	if(!validate("fc2", ConvertValue(theForm.fc2.value, theForm.fc2_mag.value, "ST"))) okToProceed = false;
	
	// For highpass check fmax as well
	if(theForm.type.value=='Highpass'){
		if(!validate("fmaxNov", ConvertValue(theForm.fmaxNov.value, theForm.fmaxNov_mag.value, "ST"))) okToProceed = false;
	}
	
	if(okToProceed){	
		// Call the below for each Filter Response Type
/*
var deg2 = "�";
alert (deg2);

alert (degreeSymbol);

alert ("deg " + deg);
alert (unescape(deg));
alert (escape(deg));
alert (unescape("%C2%B0"));
alert ("00B0");
alert (escape("00B0"));
alert (unescape("00B0"));
alert ("deg " + deg);
alert ("&#176");
alert ("&176");
alert ("&deg");
alert ("�");
alert (escape("�"));
alert (unescape("�"));
alert (escape("&deg;"));
alert (unescape("&deg;"));
alert (escape("&#176;"));
alert (unescape("&#176;"));

//alert ("filterType = " + theForm.type.value);
//alert ("filterResponse = " + theForm.type.value);
//alert ("hello " + theForm.type2.value);
var test7 = "0.5� Equiripple, 0.5&#176; Equiripple, 0.5&deg; Equiripple, 0.5&#176; Equiripple, 0.5� Equiripple, 0.5� Equiripple";
//var test7 = unescape("0.5" + &00B0; + " Equiripple");

alert ("test7 = " + test7);
*/
		// Butterworth
		for(var order=2; order<=orderMax; order++){
			result = getOrder(butterworthArray, filterType, order, Ho, Wo, W);

			// Test to see if the result exceeds the a min
			if(Math.abs(result) >= Math.abs(aMin)){
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Butterworth - Order: " + order;
				filterArray[itemIndex][1] = "Butterworth|" + order;
				itemIndex++
				break;	
			}
			else if (order == orderMax) 
			{			
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Butterworth > 8th Order";
				filterArray[itemIndex][1] = "Butterworth|" + -1;
				itemIndex++
			}
		}
	
		// Bessel
		for(var order=2; order<=orderMax; order++){
			result = getOrder(besselArray, filterType, order, Ho, Wo, W);

			// Test to see if the result exceeds the a min
			if(Math.abs(result) >= Math.abs(aMin)){
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Bessel - Order: " + order;
				filterArray[itemIndex][1] = "Bessel|" + order;
				itemIndex++
				break;	
			}
			else if (order == orderMax) 
			{				
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Bessel > 8th Order";
				filterArray[itemIndex][1] = "Bessel|" + -1;
				itemIndex++
			}		
		}
		
		// 0.05 Equiripple
		for(var order=2; order<=orderMax; order++){
			result = getOrder(pt05equirppleArray, filterType, order, Ho, Wo, W);


			// Netscape and IE seem to encode the degree symbol differently.  Need
			// to detect the browser type in order to properly encode the degree symbol
				
			if (browserType == "Netscape") {

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.05" + unescape("%C2%B0") + " Equiripple - Order: " + order;
					filterArray[itemIndex][1] = "0.05" + unescape("%C2%B0") + " Equiripple|" + order;
					itemIndex++
					break;	
				}
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.05" + unescape("%C2%B0") + " Equiripple > 8th Order";
					filterArray[itemIndex][1] = "0.05" + unescape("%C2%B0") + " Equiripple|" + -1;
					itemIndex++
				}		

			}
			else {   // browser is IE

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.05" + degreeSymbol + " Equiripple - Order: " + order;
					filterArray[itemIndex][1] = "0.05" + degreeSymbol + " Equiripple|" + order;
					itemIndex++
					break;	
				}
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.05" + degreeSymbol + " Equiripple > 8th Order";
					filterArray[itemIndex][1] = "0.05" + degreeSymbol + " Equiripple|" + -1;
					itemIndex++
				}	
			}
		}	
		
		// 0.5 Equiripple
		for(var order=2; order<=orderMax; order++){
			result = getOrder(pt5equirppleArray, filterType, order, Ho, Wo, W);

			if (browserType == "Netscape") {

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.5" + unescape("%C2%B0") + " Equiripple - Order: " + order;
					filterArray[itemIndex][1] = "0.5" + unescape("%C2%B0") + " Equiripple|" + order;
					itemIndex++
					break;	
				}
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.5" + unescape("%C2%B0") + " Equiripple > 8th Order";
					filterArray[itemIndex][1] = "0.5" + unescape("%C2%B0") + " Equiripple|" + -1;
					itemIndex++
				}		

			}
			else {   // browser is IE

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.5" + degreeSymbol + " Equiripple - Order: " + order;
					filterArray[itemIndex][1] = "0.5" + degreeSymbol + " Equiripple|" + order;
					itemIndex++
					break;	
				}
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.5" + degreeSymbol + " Equiripple > 8th Order";
					filterArray[itemIndex][1] = "0.5" + degreeSymbol + " Equiripple|" + -1;
					itemIndex++
				}	
			}	
		}
		
		// 6 dB Gaussian
		for(var order=3; order<=orderMax; order++){
			result = getOrder(db6GaussianArray, filterType, order, Ho, Wo, W);

			// Test to see if the result exceeds the a min
			if(Math.abs(result) >= Math.abs(aMin)){
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Gaussian to 6dB - Order: " + order;
				filterArray[itemIndex][1] = "Gaussian to 6dB|" + order;
				itemIndex++
				break;
			}
			else if (order == orderMax) 
			{				
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Gaussian to 6dB > 8th Order";
				filterArray[itemIndex][1] = "Gaussian to 6dB|" + -1;
				itemIndex++
			}		
		}
		
		// 12 dB Gaussian
		for(var order=3; order<=orderMax; order++){
			result = getOrder(db12GaussianArray, filterType, order, Ho, Wo, W);

			// Test to see if the result exceeds the a min
			if(Math.abs(result) >= Math.abs(aMin)){
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Gaussian to 12dB - Order: " + order;
				filterArray[itemIndex][1] = "Gaussian to 12dB|" + order;
				itemIndex++
				break;
			}
			else if (order == orderMax) 
			{				
				filterArray[itemIndex] = new Array(1);
				filterArray[itemIndex][0] = "Gaussian to 12dB > 8th Order";
				filterArray[itemIndex][1] = "Gaussian to 12dB|" + -1;
				itemIndex++
			}		
		}	


		if(aMax>=0.01){
			// 0.01 Chebyshev
			for(var order=2; order<=orderMax; order++){
				result = getOrder(pt01chebyshevArray, filterType, order, Ho, Wo, W);

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.01dB Chebyshev - Order: " + order;
					filterArray[itemIndex][1] = "0.01dB Chebyshev|" + order;
					itemIndex++			
					break;		
				}	
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.01dB Chebyshev > 8th Order";
					filterArray[itemIndex][1] = "0.01dB Chebyshev|" + -1;
					itemIndex++
				}		
			}					
		}


		if(aMax>=0.1){
			// 0.1 Chebyshev
			for(var order=2; order<=orderMax; order++){
				result = getOrder(pt1chebyshevArray, filterType, order, Ho, Wo, W);

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.1dB Chebyshev - Order: " + order;
					filterArray[itemIndex][1] = "0.1dB Chebyshev|" + order;
					itemIndex++			
					break;		
				}	
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.1dB Chebyshev > 8th Order";
					filterArray[itemIndex][1] = "0.1dB Chebyshev|" + -1;
					itemIndex++
				}						
			}
		}

		if(aMax>=0.25){
			// 0.25 Chebyshev
			for(var order=2; order<=orderMax; order++){
				result = getOrder(pt25chebyshevArray, filterType, order, Ho, Wo, W);

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.25dB Chebyshev - Order: " + order;
					filterArray[itemIndex][1] = "0.25dB Chebyshev|" + order;
					itemIndex++			
					break;		
				}	
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.25dB Chebyshev > 8th Order";
					filterArray[itemIndex][1] = "0.25dB Chebyshev|" + -1;
					itemIndex++
				}						
			}
		}

		if(aMax>=0.5){
			// 0.5 Chebyshev
			for(var order=2; order<=orderMax; order++){
				result = getOrder(pt5chebyshevArray, filterType, order, Ho, Wo, W);

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.5dB Chebyshev - Order: " + order;
					filterArray[itemIndex][1] = "0.5dB Chebyshev|" + order;
					itemIndex++			
					break;		
				}	
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "0.5dB Chebyshev > 8th Order";
					filterArray[itemIndex][1] = "0.5dB Chebyshev|" + -1;
					itemIndex++
				}						
			}										

		}

		if(aMax>=1.0){
			// 1.0 Chebyshev
			for(var order=2; order<=orderMax; order++){
				result = getOrder(pt10chebyshevArray, filterType, order, Ho, Wo, W);

				// Test to see if the result exceeds the a min
				if(Math.abs(result) >= Math.abs(aMin)){
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "1.0dB Chebyshev - Order: " + order;
					filterArray[itemIndex][1] = "1.0dB Chebyshev|" + order;
					itemIndex++			
					break;		
				}	
				else if (order == orderMax) 
				{				
					filterArray[itemIndex] = new Array(1);
					filterArray[itemIndex][0] = "1.0dB Chebyshev > 8th Order";
					filterArray[itemIndex][1] = "1.0dB Chebyshev|" + -1;
					itemIndex++
				}					
			}
		}


		
		
		fillSelectFromArray(document.novicePath.responseOrder, filterArray);
		if(!validate("responseOrder", filterArray.length)){
			toggle("generalError", "");
			window.location.href="#top";
		}
		toggle("", "generalError");
		toggle('userEntry', '');
		toggle('filterResponseSection', '');
		window.location.href='#responseType';
	}
	else{
		toggle("generalError", "");
		window.location.href="#top";
	}
	return false;
}

function fillSelectFromArray(selectCtrl, itemArray) {
	// empty existing items
	for (var i=selectCtrl.options.length; i>=0; i--) {
		selectCtrl.options[i] = null;
	}
	
	if (itemArray != null) {
		// add new items
		for (i=0; i<itemArray.length; i++) {
			selectCtrl.options[i] = new Option(itemArray[i][0]);

			if (itemArray[i][1] != null) {
				selectCtrl.options[i].value = itemArray[i][1];
			}
		}
	}
	else{
		selectCtrl.options[i] = new Option("");
		selectCtrl.options[i].value = "No Filter Responses Found"
	}	
}