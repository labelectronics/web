function displayError(ErrorName, ErrorText){
	var elem = document.getElementById(ErrorName);
	if(elem) elem.innerHTML = ErrorText;
}

function validate(itemName, itemValue){
	var validRange = true;
	
	switch(itemName){
		case "amin":
			if(isNaN(itemValue) || itemValue.toString()==""){
				errorMsg = "Amin is a required field";
				validRange = false;
			}
			break;
		case "amax":
			if(isNaN(itemValue) || itemValue.toString()==""){
				errorMsg = "Amax is a required field";
				validRange = false;
			}		
			break;
		case "fs":
			if(isNaN(itemValue) || itemValue.toString()=="" || itemValue==""){
				errorMsg = "Fs is a required field";
				validRange = false;
			}		
			break;
			
		case "fc":
			if(itemValue==""){
				errorMsg = "Fc is a required field";
				validRange = false;
			}
			else if(itemValue <= 0 || isNaN(itemValue)){
				errorMsg = "Fc must be greater than zero";
				validRange = false;
			}				
			break;
		case "fc1":
			if(itemValue==""){
				errorMsg = "Fc is a required field";
				validRange = false;
			}
			else if(itemValue <= 0 || isNaN(itemValue)){
				errorMsg = "Fc must be greater than zero";
				validRange = false;
			}				
			break;
		case "fc2":
			if(itemValue==""){
				errorMsg = "Fc is a required field";
				validRange = false;
			}
			else if(itemValue <= 0 || isNaN(itemValue)){
				errorMsg = "Fc must be greater than zero";
				validRange = false;
			}				
			break;
		case "fmax":
			if(isNaN(itemValue) || itemValue.toString()=="" || itemValue==""){
				errorMsg = "Fmax is a required field";
				validRange = false;
			}		
			break;
		case "fmaxNov":
			if(isNaN(itemValue) || itemValue.toString()=="" || itemValue==""){
				errorMsg = "Fmax is a required field";
				validRange = false;
			}		
			break;			
		case "responseOrder":
		
			if(itemValue == ""){
				errorMsg = "This is a required field";
				validRange = false;
			}

			else if(itemValue == 1){
				errorMsg = "No responses found for the given filter criteria.  Please modify your search."
				validRange = false;
			}
			break;
		case "responseOrder8th":
		
			var temp = itemValue.split('|'); 
			if(temp[1] == -1){
				errorMsg = "Choices above an 8th order are invalid. Please select another option or modify your search criteria.";
				validRange = false;
			}
			break;			
		default:
			// Do Nothing
			break;
	}
	
	if(validRange)
		displayError(itemName + "Error", "");
	else
		displayError(itemName + "Error", errorMsg);
	
	return validRange;
}

function validate8thOrderCk(value) {

   var errorMsg = "Choices above an 8th order are invalid. Please select another option or modify your search criteria.";
   var temp = value.split('|'); 	
  
   if (temp[1] == -1 ) {
       displayError("responseOrder8thError", errorMsg);
   }
   else  {
   
       displayError("responseOrder8thError", "");
   }
}


function resetError(error) {
   displayError(error, "");
   return true;
}

function validateFrequencyValuesCk(ftype, fcVal, fc_magVal, fsVal, fs_magVal) {


   var validFreq = true;
   var errorMsg;
   var itemName = "fsError";
   

  fcVal = ConvertValue(fcVal, fc_magVal, "ST")
  fsVal = ConvertValue(fsVal, fs_magVal, "ST") 


   if (ftype == "Lowpass") {
 
   	if (fcVal >= fsVal) { 
   	   validFreq = false;
   	   errorMsg = "Fc < Fs for lowpass filters.";
   	}
   }
   else {  // Highpass

   	if (fsVal >= fcVal) { 
   	   validFreq = false;
   	   errorMsg = "Fs < Fc for highpass filters.";
   	}
   }
  
   if(validFreq) {
	displayError(itemName, "");

   }
   else {

	displayError(itemName, errorMsg);

   }
   
   return validFreq;
}

function validateUserEntry(theForm){
	var okToProceed = true;
	

	
	// VALIDATE THE DIFFERENT LOCATIONS FC MIGHT OCCUR DEPENDING ON PATH & RESPONSE TYPE
	if(document.getElementById("yes").checked){
		if(!validate("fc", ConvertValue(document.expertPath.fc.value, document.expertPath.fc_mag.value, "ST"))) okToProceed = false;
		 
		if(document.expertPath.type.value=='Highpass'){
			if(!validate("fmax", ConvertValue(document.expertPath.fmax.value, document.expertPath.fmax_mag.value, "ST"))) okToProceed = false;
		}
	}
	else{
		if(document.novicePath.type.value=='Bandpass'){
			if(!validate("fc1", ConvertValue(document.novicePath.fc1.value, document.novicePath.fc1_mag.value, "ST"))) okToProceed = false;
			
		}
		else{
	
			if(document.novicePath.type.value=='Highpass'){
				if(!validate("fmaxNov", ConvertValue(document.novicePath.fmaxNov.value, document.novicePath.fmaxNov_mag.value, "ST"))) okToProceed = false;



				if(!validateFrequencyValuesCk("Highpass", document.novicePath.fc2.value, document.novicePath.fc2_mag.value, document.novicePath.fs.value, document.novicePath.fs_mag.value)) okToProceed = false;
			}
			else {
				if(!validateFrequencyValuesCk("Lowpass", document.novicePath.fc2.value, document.novicePath.fc2_mag.value, document.novicePath.fs.value, document.novicePath.fs_mag.value)) okToProceed = false;
			}
			if(!validate("fc2", ConvertValue(document.novicePath.fc2.value, document.novicePath.fc2_mag.value, "ST"))) okToProceed = false;
		}
		// VALIDATE THE DYNAMIC RESPONSE ORDER IF ON THE NOVICE PATH
		if(!validate("responseOrder", document.novicePath.responseOrder.value)) okToProceed = false;	
		if(!validate("responseOrder8th", document.novicePath.responseOrder.value)) okToProceed = false;	
		
	}
	
	if(!validateIndependentVariables(theForm)) okToProceed = false;
	
	if(okToProceed){
		toggle("", "generalError");
		if(theForm.name!="expertPath") submitForm(theForm);
	}
	else{
		toggle("generalError", "");
		window.location.href="#top";
	}
	return okToProceed;
}

function validateIndependentVariables(theForm){
	var okToProceed = true;
	var rangeErrMsg = " was invalid or not within specified range.<br>";
	
	// CLEAR ALL ERROR MESSAGES
	displayError("vsError", "");
	displayError("inputSigError", "");
	displayError("cmvError", "");
	displayError("gainError", "");

	// VALIDATE POWER SUPPLY RANGE
	if(theForm.vs.value == ""){
		theForm.vs.value = 15;
		theForm.vsSign[1].checked = true;
	}
	
	// 0 is the single supply option
	if(theForm.vsSign[0].checked){
		if(theForm.vs.value < 1.8 || theForm.vs.value > 18 || isNaN(theForm.vs.value)){
			displayError("vsError", "Power Supply " + rangeErrMsg);
			okToProceed = false;
		}
	}
	else{
		if(theForm.vs.value < -18 || theForm.vs.value > 18 || isNaN(theForm.vs.value)){
			displayError("vsError", "Power Supply " + rangeErrMsg);
			okToProceed = false;
		}
	}

	// VALIDATE INPUT SIGNAL RANGE
	if(theForm.inputSig.value == ""){
		theForm.inputSig.value = 1;
		theForm.inputSig_mag.selectedIndex = 0;  // P-P
	}
	else{
		if(theForm.inputSig_mag.selectedIndex == 0){
			if(theForm.inputSig.value < 0.000001 || theForm.inputSig.value > 18 || isNaN(theForm.inputSig.value)){
				displayError("inputSigError", "Input Signal " + rangeErrMsg);
				okToProceed = false;
			}
		}
		else{
			if(theForm.inputSig.value < 0 || theForm.inputSig.value > 1000000 || isNaN(theForm.inputSig.value)){
				displayError("inputSigError", "Input Signal " + rangeErrMsg);
				okToProceed = false;
			}
		}
	}

	//VALIDATE CMV RANGE
	if(theForm.cmv.value == "")
		theForm.cmv.value = 0;
	else if(isNaN(theForm.cmv.value)){
		displayError("cmvError", "Common Mode Voltage " + rangeErrMsg);
		okToProceed = false;
	}
	
	if(Math.abs(theForm.cmv.value) > Math.abs(theForm.vs.value)){
		displayError("cmvError", "Common Mode Voltage " + rangeErrMsg);
		okToProceed = false;
	}
	
	//VALIDATE GAIN RANGE
	if(theForm.gain.value == "") 
		theForm.gain.value = 1;
	else if(isNaN(theForm.gain.value)){
		displayError("gainError", "Gain " + rangeErrMsg);
		okToProceed = false;
	}		
	
	if(theForm.gain.value < 1 || theForm.gain.value > 100){
		displayError("gainError", "Gain " + rangeErrMsg);
		okToProceed = false;
	}

	return okToProceed;
}


function ConvertValue(inputValue, inputMag, outputMag){
    var inputScale
	dic = new Array();
       
    dic["T"] = 0.000000000001;
    dic["G"] = 0.000000001;
    dic["M"] = 0.000001;
    dic["k"] = 0.001;
    dic["m"] = 1000;
    dic["mu"] = 1000000;
    dic["n"] = 1000000000;
    dic["p"] = 1000000000000;
    dic["f"] = 1000000000000000;
    dic["ST"] = 1;
    
    var inputScale = dic[inputMag]
    var outputScale = dic[outputMag]
    return (inputValue / inputScale * outputScale)
}