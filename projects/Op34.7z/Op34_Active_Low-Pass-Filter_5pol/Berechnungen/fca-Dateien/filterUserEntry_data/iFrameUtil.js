/********************************
FILENAME: IFRAMEUNTIL.JS
CREATED BY: SANTOSH TRIPATHY
CREATED ON: 03/26/2008
DESCRIPTION: CONSISTS OF FUNCTION TO RESIZE IFRAMES
-----------------------
MODIFICATION LOG:
MODIFIED ON		MODIFIED BY	DESCRIPTION
03/26/2008		JYOTSNA THAMMINEEDI	RENAMED CHANGEHEIGHT FUNCTION AS RESIZEIFRAME
********************************/

/************************************************
IN THE SOURCE DOCUMENT OF THE IFRAME, DECLARE AND SET TO TRUE A VARIABLE CALLED bDontChangeFrameDomain, IF THE IFRAME
IS LOADING FROM A DOMAIN THAT IS DIFFERENT FROM THE CALLING PAGE.
*************************************************/
if (typeof(bDontChangeFrameDomain) =='undefined')
{
    document.domain="analog.com";
}

/*****************************
FUNCTION: resizeMyFrame
PARAMETERS: iframeID string optional, iframeHeight string optional 
CAN BE CALLED 4 DIFFERENT WAYS:
	resizeMyFrame() //SETS IFRAME NAME fcaFrame TO THE HEIGHT OF ITS CONTENT
	resizeMyFrame(strFrameID, strHeight) //SETS A GIVEN IFRAME TO THE HEIGHT SPECIFIED
	resizeMyFrame(strFrameID) //SETS A GIVEN IFRAME TO THE HEIGHT OF ITS CONTENT
	resizeMyFrame('',strHeight) //SETS IFRAME NAME fcaFrame TO THE HEIGHT SPECIFIED
DESCRIPTION:
DYNAMICALLY RESIZES IFRAME BASED ON IFRAME CONTENT
PRE-REQUISITES: IFRAME SHOULD BE NAME FCAFRAME
PARAMETERS: strFrameID, strHeight
SHOULD BE CALLED FROM BODY ONLOAD METHOD OF PAGE BEING USED INSIDE IFRAMES
**********************************/
function resizeMyFrame(in_strFrameID, strHeight)
	{
		var objFrame;
		var lStrFrameID = 'fcaFrame';
		
		try
		{
		    //IF A SPECIFIC IFRAME ID WAS PASSED IN, USE IT.
		    //OTHERWISE, DEFAULT TO FCAFRAME
			if (typeof(in_strFrameID)!="undefined")
			{
			    lStrFrameID = in_strFrameID;
			}
			
			//GET THE OBJECT REFERENCE TO THE IFRAME
			if (lStrFrameID.length != '')
			{
				objFrame = parent.window.document.getElementById(lStrFrameID);
			}
			else
			{
			    return;
			}
		}
		catch(err)
		{
		    
		    return;
		}
		
		if (typeof(objFrame) != "undefined")
		{
			resizeIFrame(objFrame,strHeight);
		}
	};

//THIS IS A PRIVATE FUNCTION.
//DO NOT USE THIS FUNCTION DIRECTLY
function resizeIFrame(iframe, strHeight)
{
	try
	{
		if (typeof(gStrFixedHeight)=="undefined" && typeof(strHeight)=="undefined")
		{
			iframe.style.height = "400px"; //Need to reset height before doing the following for Mozilla
			if (iframe.Document) //IE
			{
			    var myHeight = this.document.body.scrollHeight+10;
				iframe.style.height = myHeight+"px";
			}
			else //tested with Mozilla
			{
			    
				var myHeight = this.document.body.offsetHeight + 32;
				if (myHeight < 32768)
				{
					iframe.style.height = myHeight +"px";
				}
			}
		}
		else
		{
			var lSTRHeight="400px";
			if (typeof(strHeight) != 'undefined') lSTRHeight = strHeight;
			else if (typeof(gStrFixedHeight) != 'undefined') lSTRHeight = gStrFixedHeight;
			
			iframe.style.height = lSTRHeight;
		}
	}
	catch(err)
	{
		
	}
}
