/* existing code
/************************ ADDITIONAL FEATURES ************************
     Plugins
*/
/************************** CONFIG SECTION **************************/
/* You may add or alter any code config here.                       */
var s_charSet="ISO-8859-1" //must be ISO-8859-1 for utf-8 pages because of translation
/* Specify the Report Suite ID(s) to track here */
var s_account="analogcom"
/* E-commerce Config */
var s_currencyCode="USD"
var s_eVarCFG=""
/* Link Tracking Config */
var s_trackDownloadLinks=true
var s_trackExternalLinks=true
var s_trackInlineStats=true
var s_linkDownloadFileTypes="exe,zip,wav,mp3,mov,mpg,avi,wmv,doc,pdf,xls,pps,h,txt,swf,cab,cir,ibs,sin,mdl,m,dat,jar,js,tgz,gz,ppt,vdu"
var s_linkInternalFilters="javascript:,analog,soundmax"
var s_linkLeaveQueryString=true
var s_linkTrackVars="None"
var s_linkTrackEvents="None"
/* PageName Config */
var s_siteID="//"+window.location.hostname; // domain name
var s_defaultPage="index.html";
var s_queryVarsList=""; // if query params need to be included, comma delimit
var s_pathExcludeDelim=";"; //do not adjust
var s_pathConcatDelim="/"; // page name component separator
/* Plugin Config */
var s_usePlugins=true

function s_doPlugins() {
	
/*
 * Keyword Optimization Implementation
 */
var locationstring=unescape(location.href);
if(locationstring.indexOf('?sourceid=') > 0){
	//Set temp variables	
	var engine="";
	var searchCmp="";
	var adGroup="";
	var keyword="";
	var landPageType="";
	var prodTab="";
	var paramValues=new Array();

	//Split the query string and set values in an array
	var queryvalue=locationstring.substr(locationstring.indexOf('?sourceid=')+10);
	paramValues = splitQueryString(queryvalue);
	engine = paramValues[0];
	searchCmp=paramValues[1];
	adGroup=paramValues[2];
	keyword=paramValues[3];
	landPageType=paramValues[4];
	prodTab=paramValues[5];

	//Set values in eVars
	s_eVar1=engine;
	s_eVar3=searchCmp;
        s_eVar4=adGroup;
        s_eVar5=keyword;
        s_eVar6=landPageType;
        s_eVar7=prodTab;

}//end if

//Persist the query string in a cookie (setAndPersist splits the qs & sets prop12-prop17) 
        s_vp_setAndPersistValue('',queryvalue,0);

//Pathing for each value
	/* prop_to_populate, q-string param, preface (optional) */
	s_vp_propPath('s_prop19',searchCmp,'SearchCmp');	

/* End Keyword Optimization Implementation */

	/* Handle SDK Downloads */
	var linkURL=s_vp_linkHandler('.exe','d');
	if (linkURL){
		if (!s_vp_getValue('s_events')) {s_events="event6";}
		else {s_events=s_vp_getValue('s_events')+",event6";}
		s_eVar12=linkURL;
		s_linkTrackVars="eVar12,events,prop24,prop25,prop26,prop27,prop28";
		s_linkTrackEvents="event6";		
	}


	/* End of addition by Infosys on 13-Dec-2006*/
	
	/* Add calls to plugins here */
	//populate campaign when "ref" param is found in URL
	s_vp_getCGI('s_campaign','ref');
        // remove tracking codes that don't begin with ASC, DSPS, MCP or CORP
        var c=s_vp_getValue('s_campaign');
        c=c.toLowerCase();
        if(c.indexOf('asc')!=0&&c.indexOf('dsps')!=0&&c.indexOf('mcp')!=0&&c.indexOf('corp')!=0)
        s_vpr('s_campaign','');	
	//use first-party cookies
	firstPartyCookie();
	//pathing by language
	if(s_channel!="" && s_pageName!=""){
		s_vpr('s_prop4',s_channel+" : "+s_pageName);
	}
	//pathing by campaigns
	s_vp_cmpPath("s_prop5","Campaign = ","val");
	//put the url in prop6
	if ((!window.s_pageType) && (!window.s_prop6 || s_prop6==""))
	s_vpr("s_prop6", s_vp_getPageName());
	
	s_vp_linkHandler('.exe|.zip|.wav|.mp3|.mov|.mpg|.avi|.wmv|.doc|.pdf|.xls|.ppt','d');
}
/************************** PLUGINS SECTION *************************/
/*
 * Plugin: Prop pathing. Enables pathing with q-string and pagename
 * on the landing page only.
 */
function s_vp_propPath(vs,k,p)
	{var v='',l=s_wd.location,pn=s_vp_getValue('s_pageName')?
	s_vp_getValue('s_pageName'):l.protocol+'//'+l.hostname+l.pathname;
	if(k)v=k;if(v)v=(p?p+': '+
	v:v)+': '+pn;else v=pn;s_vpr(vs,v);}
/*
 * Plugin: splitQueryString (capture param values delimited by an underscore)
 *         Returns an array with values
 */
function splitQueryString(v){
var temp = new Array();
temp = v.split('_');
return temp;
}
/*
 * Plugin: Custom Page Path v1.0 
 */
function s_vp_getCustomPagePath(s,v,c,p) {
var pn=s_vp_getValue("s_pageName");
var t=new Date;t.setTime(t.getTime()+1800000); 
if(v){if(s_c_w(c,v,t)){s_vpr(s,p+v+":"+pn)}}
else{v=s_c_r(c);if(v){s_c_w(c,v,t);s_vpr(s,pn);}}
}
/*
 * Plugin: setAndPersistValue 0.1 - get a value on every page (modified 12-21-06) 
 */
/*
* Plugin: setAndPersistValue 0.1 - get a value on every page
*/
function s_vp_setAndPersistValue(vs, v, a) {
    var l, e = new Date;
    if (v) {
        e.setTime(e.getTime() + a * 86400000);
        s_c_w('s_p_' + vs, v, a ? e : a)
    }
    ;
    l = s_c_r('s_p_' + vs);
    qs = splitQueryString(l);
    
    s_vpr('s_prop12',qs[0]);
    s_vpr('s_prop13',qs[1]);
    s_vpr('s_prop14',qs[2]);
    s_vpr('s_prop15',qs[3]);
    s_vpr('s_prop16',qs[4]);
    s_vpr('s_prop17',qs[5]);
}
/*
 * Plugin: linkHandler 0.5 - identify and report custom links
 */
function s_vp_linkHandler(p,t){
var h=s_p_gh(),i,l;t=t?t:'o';if(!h||(s_linkType&&(h||s_linkName)))
return '';i=h.indexOf('?');h=s_gg('linkLeaveQueryString')||i<0?h:
h.substring(0,i);l=s_pt(p,'|',s_p_gn,h.toLowerCase());if(l){s_linkName
=l=='[['?'':l;s_linkType=t;return h}return ''}function s_p_gn(t,h){var
i=t?t.indexOf('~'):-1,n,x;if(t&&h){n=i<0?'':t.substring(0,i);x=
t.substring(i+1);if(h.indexOf(x.toLowerCase())>-1)return n?n:'[['}
return 0}function s_p_gh(){if(!s_eo&&!s_lnk)return '';var o=s_eo?s_eo:
s_lnk,y=s_ot(o),n=s_oid(o),x=o.s_oidt;if(s_eo&&o==s_eo){while(o&&!n&&y
!='BODY'){o=o.parentElement?o.parentElement:o.parentNode;if(!o)
return '';y=s_ot(o);n=s_oid(o);x=o.s_oidt}}return o.href?o.href:''}

/*
 * Plugin: Track Campaign Pathing
 */
function s_vp_cmpPath(s,p,v) {
   /* 
   campaign pathing via an s_prop
   first page sets s_prop = cmpPrefix + campaignID + pagename 
	subsequent pages set s_prop = cmpPrefix + pagename 
	s = s_prop to use
	p = report prefix for landing page
	*/
	var tp = s_vp_getValue("s_pageName");
	if(s_vp_getValue("s_campaign")){
		var tc = s_vp_getValue("s_campaign");
	}
	var ck = "cmpPath"; //cookie name
	if(tc) {
		if(v=="val"){
			s_vpr(s,p+tc+" : "+tp);
		} else if (v=="noVal"){ 
			s_vpr(s,p+" : "+tp);
		}
		s_c_w(ck,tc,0);
	} else if (s_c_r(ck)) { 
		s_vpr(s,"Path Page : "+tp) 
	}
}
/*
 * Plugin: Get Plugin Modified Value
 */
function s_vp_getValue(vs)
	{var k=vs.substring(0,2)=='s_'?vs.substring(2):vs;return s_wd[
	's_vpm_'+k]?s_wd['s_vpv_'+k]:s_gg(k)}
/*
 * Plugin: Get Query String CGI Variable Value
 */
function s_vp_getCGI(vs,k)
	{var v='';if(k&&s_wd.location.search){var q=s_wd.location.search,
	qq=q.indexOf('?');q=qq<0?q:q.substring(qq+1);v=s_pt(q,'&',s_cgif,
	k)}s_vpr(vs,v)}function s_cgif(t,k){if(t){var te=t.indexOf('='),
	sk=te<0?t:t.substring(0,te),sv=te<0?'True':t.substring(te+1);if(
	sk==k)return s_epa(sv)}return ''}
/*
 * Plugin: Get Value From Cookie
 */
function s_vp_getCookie(vs,k)
	{s_vpr(vs,s_c_r(k))}
/*
 * Plugin: Get/Set UniqueID from 1st Party Cookie set value to s_prop11
 */
function firstPartyCookie() {

	// cookie expiration
	var e=new Date;
	e.setTime(e.getTime()+5*30758400000);

	// get cookie value from sc_id or analog cookie
	var cv=s_c_r("sc_id");
	if(!cv) cv=s_c_r("ADIOMNITURESTATSCOOKIE");

	// if cookie is written, populate prop11
	if(cv&&s_c_w("sc_id",cv,e)){
		s_vpr("s_prop11",cv);
	}
}
/*
 * Utility Function: Split a string (compatible with Javascript 1.0)
 */
function s_split(str,sep)
	{var si=0,sa=new Array(),i;while((str.length>0)&&(sep.length>0)){
	 i=str.indexOf(sep);if((!i)&&(sep!=str.substring(0,sep.length)))
	 break;if(i==-1){sa[si++] = str;break;}sa[si++]=str.substring(0,i);
	 str=str.substring(i+sep.length,str.length)}return sa}
	
/*
 * Utility Function: Determine If A Particular Value Exists Within An Array
 */
function s_ia(ar,v)
	{for(var i=0;i<ar.length;i++){if(ar[i]==v)return i}return -1}

/*
 * Plugin: Dynamically Generate Page Name Based On Current URL
 */
function s_vp_getPageName()
	{var pn=(window.s_siteID&&(""+s_siteID).length>0)?""+s_siteID:
	'',l=location,dp=(window.s_defaultPage)?""+s_defaultPage:'',e=
	(window.s_pathExcludeDelim)?s_pathExcludeDelim:'',cs=(window.
	s_pathConcatDelim)?s_pathConcatDelim:'',q=l.search.substring(1),
	p=l.pathname.substring(1),x=p.indexOf(e);p=((x<0)?p:p.substring(0,
	x)).split("/");for(j=0;j<p.length;j++){if(p[j].length>0){if(pn.
	length>0)pn+=cs;pn+=p[j]}else{if(dp.length>0){if(pn.length>0)pn+=
	cs;pn+=dp}}}if(q.length>0){if(window.s_queryVarsList){var qpa=new 
	Array(),qv=s_queryVarsList.split(","),qp=q.split("&"),tmp,idx;for
	(i=0;i<qp.length;i++){tmp=qp[i].split("=");qpa[i]=tmp[0]}for(i=0;
	i<qv.length;i++){idx=s_ia(qpa,qv[i]);if(idx>=0){if(pn.length
	>0)pn+=cs;pn+=qp[idx]}}}}return pn}
/*
 * Plugin Utilities v2.0 (Required For All Plugins)
 */
function s_vpr(vs,v){if(s_wd[vs])s_wd[vs]=s_wd[vs];else s_wd[vs]=''
if(vs.substring(0,2) == 's_')vs=vs.substring(2);s_wd['s_vpv_'+vs]=v
s_wd['s_vpm_'+vs]=1}function s_dt(tz,t){var d=new Date;if(t)d.setTime(
t);d=new Date(d.getTime()+(d.getTimezoneOffset()*60*1000))
return new Date(Math.floor(d.getTime()+(tz*60*60*1000)))}
function s_vh_gt(k,v){var vh='|'+s_c_r('s_vh_'+k),vi=vh.indexOf('|'+v
+'='),ti=vi<0?vi:vi+2+v.length,pi=vh.indexOf('|',ti),t=ti<0?'':
vh.substring(ti,pi<0?vh.length:pi);return t}function s_vh_gl(k){var
vh=s_c_r('s_vh_'+k),e=vh?vh.indexOf('='):0;return vh?(vh.substring(0,
e?e:vh.length)):''}function s_vh_s(k,v){if(k&&v){var e=new Date,st=
e.getTime(),y=e.getYear(),c='s_vh_'+k,vh='|'+s_c_r(c)+'|',t=s_vh_gt(k,
v);e.setYear((y<1900?y+1900:y)+5);if(t)vh=s_rep(vh,'|'+v+'='+t+'|','|'
);if(vh.substring(0,1)=='|')vh=vh.substring(1);if(vh.substring(
vh.length-1,vh.length)=='|')vh=vh.substring(0,vh.length-1);vh=v
+'=[PCC]'+(vh?'|'+vh:'');s_c_w(c,vh,e);if(s_vh_gt(k,v)!='[PCC]')
return 0;vh=s_rep(vh,'[PCC]',st);s_c_w(c,vh,e)}return 1}

/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
var s_linkType,s_linkName,s_objectID,s_un,s_ios=0,s_q='',s_code='',
code='',s_bcr=0,s_lnk='',s_eo='',s_vb,s_pl,s_tfs=0,s_etfs=0,s_wd=
window,s_d=s_wd.document,s_ssl=(s_wd.location.protocol.toLowerCase(
).indexOf('https')>=0),s_n=navigator,s_u=s_n.userAgent,s_apn=
s_n.appName,s_v=s_n.appVersion,s_apv,s_i,s_ie=s_v.indexOf('MSIE '),
s_ns6=s_u.indexOf('Netscape6/'),s_em=0;if(s_v.indexOf('Opera')>=0||
s_u.indexOf('Opera')>=0)s_apn='Opera';var s_isie=(s_apn==
'Microsoft Internet Explorer'),s_isns=(s_apn=='Netscape'),s_isopera=(
s_apn=='Opera'),s_ismac=(s_u.indexOf('Mac')>=0);if(s_ie>0){s_apv=
parseInt(s_i=s_v.substring(s_ie+5));if(s_apv>3)s_apv=parseFloat(s_i)}
else if(s_ns6>0)s_apv=parseFloat(s_u.substring(s_ns6+10));else s_apv=
parseFloat(s_v);if(String.fromCharCode){s_i=escape(
String.fromCharCode(256)).toUpperCase();s_em=(s_i=='%C4%80'?2:(s_i==
'%U0100'?1:0))}function s_fl(s,l){return s?(s+'').substring(0,l):s}
function s_co(o){if(!o)return o;var n=new Object,x;for(x in o)if(
x.indexOf("select")<0&&x.indexOf("filter")<0)n[x]=o[x];return n}
function s_num(x){var s=x.toString(),g='0123456789',p,d
for(p=0;p<s.length;p++){d=s.substring(p,p+1);if(g.indexOf(d)<0)
return 0}return 1}function s_rep(s,o,n){var i=s.indexOf(o),l=n.length>
0?n.length:1;while(s&&i>=0){s=s.substring(0,i)+n+s.substring(i
+o.length);i=s.indexOf(o,i+l)}return s}function s_ape(x){var i;x=x?
s_rep(escape(''+x),'+','%2B'):x;if(x&&s_gg('charSet')&&s_em==1&&
x.indexOf('%u')<0&&x.indexOf('%U')<0){i=x.indexOf('%');while(i>=0){i++
if(('89ABCDEFabcdef').indexOf(x.substring(i,i+1))>=0)
return x.substring(0,i)+'u00'+x.substring(i);i=x.indexOf('%',i)}}
return x}function s_epa(s){return s?unescape(s_rep(''+s,'+',' ')):s}
function s_pt(s,d,f,a){var t=s,x=0,y,r;while(t){y=t.indexOf(d);y=y<0?
t.length:y;t=t.substring(0,y);r=f(t,a);if(r)return r;x+=y+d.length;t=
s.substring(x,s.length);t=x<s.length?t:''}return ''}function s_isf(t,a
){var c=a.indexOf(':');if(c>=0)a=a.substring(0,c);if(t.substring(0,2
)=='s_')t=t.substring(2);return (t!=''&&t==a)}function s_fsf(t,a){if(
s_pt(a,',',s_isf,t))s_fsg+=(s_fsg!=''?',':'')+t;return 0}var s_fsg
function s_fs(s,f){s_fsg='';s_pt(s,',',s_fsf,f);return s_fsg}var
s_c_d='';function s_c_gdf(t,a){if(!s_num(t))return 1;return 0}
function s_c_gd(){var d=s_wd.location.hostname,n=s_gg(
'cookieDomainPeriods'),p;if(d&&!s_c_d){n=n?parseInt(n):2;n=n>2?n:2;p=
d.lastIndexOf('.');while(p>=0&&n>1){p=d.lastIndexOf('.',p-1);n--}
s_c_d=p>0&&s_pt(d,'.',s_c_gdf,0)?d.substring(p):''}return s_c_d}
function s_c_r(k){k=s_ape(k);var c=' '+s_d.cookie,s=c.indexOf(' '+k
+'='),e=s<0?s:c.indexOf(';',s),v=s<0?'':s_epa(c.substring(s+2
+k.length,e<0?c.length:e));return v!='[[B]]'?v:''}function s_c_w(k,v,e
){var d=s_c_gd(),l=s_gg('cookieLifetime'),s;v=''+v;l=l?(''+l
).toUpperCase():'';if(e&&l!='SESSION'&&l!='NONE'){s=(v!=''?parseInt(l?
l:0):-60);if(s){e=new Date;e.setTime(e.getTime()+(s*1000))}}if(k&&l!=
'NONE'){s_d.cookie=k+'='+s_ape(v!=''?v:'[[B]]')+'; path=/;'+(e&&l!=
'SESSION'?' expires='+e.toGMTString()+';':'')+(d?' domain='+d+';':'')
return s_c_r(k)==v}return 0}function s_cet(f,a,et,oe,fb){var r,d=0
/*@cc_on@if(@_jscript_version>=5){try{return f(a)}catch(e){return et(e)}d=1}@end@*/
if(
!d){if(s_ismac&&s_u.indexOf('MSIE 4')>=0)return fb(a);else{s_wd.s_oe=
s_wd.onerror;s_wd.onerror=oe;r=f(a);s_wd.onerror=s_wd.s_oe;return r}}}
function s_gtfset(e){return s_tfs}function s_gtfsoe(e){s_wd.onerror=
s_wd.s_oe;s_etfs=1;var code=s_gs(s_un);if(code)s_d.write(code);s_etfs=
0;return true}function s_gtfsfb(a){return s_wd}function s_gtfsf(w){var
p=w.parent,l=w.location;s_tfs=w;if(p&&p.location!=l&&p.location.host==
l.host){s_tfs=p;return s_gtfsf(s_tfs)}return s_tfs}function s_gtfs(){
if(!s_tfs){s_tfs=s_wd;if(!s_etfs)s_tfs=s_cet(s_gtfsf,s_tfs,s_gtfset,
s_gtfsoe,s_gtfsfb)}return s_tfs}function s_ca(un){un=un.toLowerCase()
var ci=un.indexOf(','),fun=ci<0?un:un.substring(0,ci),imn='s_i_'+fun
if(s_d.images&&s_apv>=3&&!s_isopera&&(s_ns6<0||s_apv>=6.1)){s_ios=1
if(!s_d.images[imn]&&(!s_isns||(s_apv<4||s_apv>=5))){s_d.write('<im'
+'g name="'+imn+'" height=1 width=1 border=0 alt="">');if(!s_d.images[
imn])s_ios=0}}}function s_it(un){s_ca(un)}function s_mr(un,sess,q,ta){
un=un.toLowerCase();var ci=un.indexOf(','),fun=ci<0?un:un.substring(0,
ci),unc=s_rep(fun,'_','-'),imn='s_i_'+fun,ns=s_gg('visitorNamespace'),
im,b,e,rs='http'+(s_ssl?'s':'')+'://'+(ns?ns:(s_ssl?'102':unc))+'.122.2O7.net/b/ss/'+un+'/1/G.9p2/'
+sess+'?[AQB]&ndh=1'+(q?q:'')+(s_q?s_q:'')+'&[AQE]';if(s_ios){im=s_wd[
imn]?s_wd[imn]:s_d.images[imn];if(!im)im=s_wd[imn]=new Image;im.src=rs
if(rs.indexOf('&pe=')>=0&&(!ta||ta=='_self'||ta=='_top'||(s_wd.name&&
ta==s_wd.name))){b=e=new Date;while(e.getTime()-b.getTime()<500)e=
new Date}return ''}return '<im'+'g sr'+'c="'+rs
+'" width=1 height=1 border=0 alt="">'}function s_gg(v){var g='s_'+v
return s_wd[g]||s_wd.s_disableLegacyVars?s_wd[g]:s_wd[v]}
function s_gv(v){return s_wd['s_vpm_'+v]?s_wd['s_vpv_'+v]:s_gg(v)}var
s_qav='';function s_havf(t,a){var b=t.substring(0,4),s=t.substring(4),
n=parseInt(s),k='s_g_'+t,m='s_vpm_'+t,q=t,v=s_gg('linkTrackVars'),e=
s_gg('linkTrackEvents');if(!s_wd['s_'+t])s_wd['s_'+t]='';s_wd[k]=s_gv(
t);if(s_lnk||s_eo){v=v?v+',pageName,pageURL,referrer,vmk,charSet,visi'
+'torNamespace,cookieDomainPeriods,cookieLifetime,currencyCode,purcha'
+'seID':'';if(v&&!s_pt(v,',',s_isf,t))s_wd[k]='';if(t=='events'&&e)
s_wd[k]=s_fs(s_wd[k],e)}s_wd[m]=0;if(t=='pageURL')q='g';else if(t==
'referrer')q='r';else if(t=='vmk')q='vmt';else if(t=='charSet'){q='ce'
if(s_wd[k]&&s_em==2)s_wd[k]='UTF-8'}else if(t=='visitorNamespace')q=
'ns';else if(t=='cookieDomainPeriods')q='cdp';else if(t==
'cookieLifetime')q='cl';else if(t=='currencyCode')q='cc';else if(t==
'channel')q='ch';else if(t=='campaign')q='v0';else if(s_num(s)){if(b==
'prop')q='c'+n;else if(b=='eVar')q='v'+n;else if(b=='hier'){q='h'+n
s_wd[k]=s_fl(s_wd[k],255)}}if(s_wd[k]&&t!='linkName'&&t!='linkType')
s_qav+='&'+q+'='+s_ape(s_wd[k]);return ''}function s_hav(){var n,av=
'vmk,charSet,visitorNamespace,cookieDomainPeriods,cookieLifetime,page'
+'Name,pageURL,referrer,channel,server,pageType,campaign,state,zip,ev'
+'ents,products,currencyCode,purchaseID,linkName,linkType'
for(n=1;n<51;n++)av+=',prop'+n+',eVar'+n+',hier'+n;s_qav='';s_pt(av,
',',s_havf,0);return s_qav}function s_lnf(t,h){t=t?
t.toLowerCase():'';h=h?h.toLowerCase():'';var te=t.indexOf('=');if(t&&
te>0&&h.indexOf(t.substring(te+1))>=0)return t.substring(0,te)
return ''}function s_ln(h){if(s_gg('linkNames'))return s_pt(s_gg(
'linkNames'),',',s_lnf,h);return ''}function s_ltdf(t,h){t=t?
t.toLowerCase():'';h=h?h.toLowerCase():'';var qi=h.indexOf('?');h=qi>=
0?h.substring(0,qi):h;if(t&&h.substring(h.length-(t.length+1))=='.'+t)
return 1;return 0}function s_ltef(t,h){t=t?t.toLowerCase():'';h=h?
h.toLowerCase():'';if(t&&h.indexOf(t)>=0)return 1;return 0}
function s_lt(h){var lft=s_gg('linkDownloadFileTypes'),lef=s_gg(
'linkExternalFilters'),lif=s_gg('linkInternalFilters')?s_gg(
'linkInternalFilters'):s_wd.location.hostname;h=h.toLowerCase();if(
s_gg('trackDownloadLinks')&&lft&&s_pt(lft,',',s_ltdf,h))return 'd';if(
s_gg('trackExternalLinks')&&(lef||lif)&&(!lef||s_pt(lef,',',s_ltef,h)
)&&(!lif||!s_pt(lif,',',s_ltef,h)))return 'e';return ''}function s_lc(
e){s_lnk=s_co(this);s_gs('');s_lnk='';if(this.s_oc)return this.s_oc(e)
return true}function s_ls(){var l,ln,oc
for(ln=0;ln<s_d.links.length;ln++){l=s_d.links[ln];oc=l.onclick?
l.onclick.toString():'';if(oc.indexOf("s_gs(")<0&&oc.indexOf("s_lc(")<
0){l.s_oc=l.onclick;l.onclick=s_lc}}}function s_bc(e){s_eo=
e.srcElement?e.srcElement:e.target;s_gs('');s_eo=''}function s_ot(o){
var a=o.type,b=o.tagName;return (a&&a.toUpperCase?a:b&&b.toUpperCase?b
:o.href?'A':'').toUpperCase()}function s_oid(o){var t=s_ot(o),p=
o.protocol,c=o.onclick,n='',x=0;if(!o.s_oid){if(o.href&&(t=='A'||t==
'AREA')&&(!c||!p||p.toLowerCase().indexOf('javascript')<0))n=o.href
else if(c){n=s_rep(s_rep(s_rep(s_rep(c.toString(),"\r",''),"\n",''),
"\t",''),' ','');x=2}else if(o.value&&(t=='INPUT'||t=='SUBMIT')){n=
o.value;x=3}else if(o.src&&t=='IMAGE')n=o.src;if(n){o.s_oid=s_fl(n,100
);o.s_oidt=x}}return o.s_oid}function s_rqf(t,un){var e=t.indexOf('='
),u=e>=0?','+t.substring(0,e)+',':'';return u&&u.indexOf(','+un+',')>=
0?s_epa(t.substring(e+1)):''}function s_rq(un){var c=un.indexOf(','),
v=s_c_r('s_sq'),q='';if(c<0)return s_pt(v,'&',s_rqf,un);return s_pt(
un,',',s_rq,0)}var s_sqq,s_squ;function s_sqp(t,a){var e=t.indexOf('='
),q=e<0?'':s_epa(t.substring(e+1));s_sqq[q]='';if(e>=0)s_pt(
t.substring(0,e),',',s_sqs,q);return 0}function s_sqs(un,q){s_squ[un]=
q;return 0}function s_sq(un,q){s_sqq=new Object;s_squ=new Object
s_sqq[q]='';var k='s_sq',v=s_c_r(k),x,c=0;s_pt(v,'&',s_sqp,0);s_pt(un,
',',s_sqs,q);v='';for(x in s_squ)s_sqq[s_squ[x]]+=(s_sqq[s_squ[x]]?','
:'')+x;for(x in s_sqq)if(x&&s_sqq[x]&&(x==q||c<2)){v+=(v?'&':'')
+s_sqq[x]+'='+s_ape(x);c++}return s_c_w(k,v,0)}function s_wdl(e){
s_wd.s_wd_l=1;var r=true;if(s_wd.s_ol)r=s_wd.s_ol(e);if(s_wd.s_ls)
s_wd.s_ls();return r}function s_wds(un){un=un.toLowerCase()
s_wd.s_wd_l=1;if(s_apv>3&&(!s_isie||!s_ismac||s_apv>=5)){s_wd.s_wd_l=0
if(!s_wd.s_unl)s_wd.s_unl=new Array;s_wd.s_unl[s_wd.s_unl.length]=un
if(s_d.body&&s_d.body.attachEvent){if(!s_wd.s_bcr&&
s_d.body.attachEvent('onclick',s_bc))s_wd.s_bcr=1}else if(s_d.body&&
s_d.body.addEventListener){if(!s_wd.s_bcr&&s_d.body.addEventListener(
'click',s_bc,false))s_wd.s_bcr=1}else{if(!s_wd.s_olr){s_wd.s_ol=
s_wd.onload;s_wd.onload=s_wdl}s_wd.s_olr=1}}}function s_iepf(i,a){if(
i.substring(0,1)!='{')i='{'+i+'}';if(s_d.body.isComponentInstalled(i,
'ComponentID')){var n=s_pl.length;s_pl[n]=new Object;s_pl[n].name=i
+':'+s_d.body.getComponentVersion(i,'ComponentID')}return 0}
function s_vs(un,x){var s=s_gg('visitorSampling'),g=s_gg(
'visitorSamplingGroup'),k='s_vsn_'+un+(g?'_'+g:''),n=s_c_r(k),e=
new Date,y=e.getYear();e.setYear(y+10+(y<1900?1900:0));if(s){s*=100
if(!n){if(!s_c_w(k,x,e))return 0;n=x}if(n%10000>s)return 0}return 1}
function s_dyasmf(t,m){if(t&&m&&m.indexOf(t)>=0)return 1;return 0}
function s_dyasf(t,m){var i=t?t.indexOf('='):-1,un,s;if(i>=0&&m){var
un=t.substring(0,i),s=t.substring(i+1);if(s_pt(s,',',s_dyasmf,m))
return un}return 0}function s_dyas(un,l,m){if(!m)m=s_wd.location.host
if(!m.toLowerCase)m=m.toString();l=l.toLowerCase();m=m.toLowerCase()
var nun=s_pt(l,';',s_dyasf,m);if(nun)return nun;return un}
function s_gs(un){un=un.toLowerCase();var dyas=s_gg(
'dynamicAccountSelection'),dyal=s_gg('dynamicAccountList'),dyam=s_gg(
'dynamicAccountMatch');if(dyas&&dyal)un=s_dyas(un,dyal,dyam);s_un=un
var trk=1,tm=new Date,sed=Math&&Math.random?Math.floor(Math.random()
*10000000000000):tm.getTime(),sess='s'+Math.floor(tm.getTime()/
10800000)%10+sed,yr=tm.getYear(),vt=tm.getDate()+'/'+tm.getMonth()+'/'
+(yr<1900?yr+1900:yr)+' '+tm.getHours()+':'+tm.getMinutes()+':'
+tm.getSeconds()+' '+tm.getDay()+' '+tm.getTimezoneOffset(),tfs=
s_gtfs(),vt,ta='',q='',qs='';if(!s_q){var tl=tfs.location,s='',c='',v=
'',p='',bw='',bh='',j='1.0',k=s_c_w('s_cc','true',0)?'Y':'N',hp='',ct=
'',iepl=s_gg('iePlugins'),pn=0,ps;if(s_apv>=4)s=screen.width+'x'
+screen.height;if(s_isns||s_isopera){if(s_apv>=3){j='1.1';v=
s_n.javaEnabled()?'Y':'N';if(s_apv>=4){j='1.2';c=screen.pixelDepth;bw=
s_wd.innerWidth;bh=s_wd.innerHeight;if(s_apv>=4.06)j='1.3'}}s_pl=
s_n.plugins}else if(s_isie){if(s_apv>=4){v=s_n.javaEnabled()?'Y':'N'
j='1.2';c=screen.colorDepth;if(s_apv>=5){bw=
s_d.documentElement.offsetWidth;bh=s_d.documentElement.offsetHeight;j=
'1.3';if(!s_ismac&&s_d.body){s_d.body.addBehavior("#default#homePage")
hp=s_d.body.isHomePage(tl)?"Y":"N";s_d.body.addBehavior(
"#default#clientCaps");ct=s_d.body.connectionType;if(iepl){s_pl=
new Array;s_pt(iepl,',',s_iepf,'')}}}}else r='';if(!s_pl&&iepl)s_pl=
s_n.plugins}if(s_pl)while(pn<s_pl.length&&pn<30){ps=s_fl(s_pl[pn
].name,100)+';';if(p.indexOf(ps)<0)p+=ps;pn++}s_q=(s?'&s='+s_ape(s):''
)+(c?'&c='+s_ape(c):'')+(j?'&j='+j:'')+(v?'&v='+v:'')+(k?'&k='+k:'')+(
bw?'&bw='+bw:'')+(bh?'&bh='+bh:'')+(ct?'&ct='+s_ape(ct):'')+(hp?'&hp='
+hp:'')+(s_vb?'&vb='+s_vb:'')+(p?'&p='+s_ape(p):'')}if(s_gg(
'usePlugins'))s_wd.s_doPlugins();var l=s_wd.location,r=
tfs.document.referrer;if(!s_gg("pageURL"))s_wd.s_pageURL=s_fl(l?l:'',
255);if(!s_gg("referrer"))s_wd.s_referrer=s_fl(r?r:'',255);if(s_lnk||
s_eo){var o=s_eo?s_eo:s_lnk;if(!o)return '';var p=s_gv('pageName'),w=
1,t=s_ot(o),n=s_oid(o),x=o.s_oidt,h,l,i,oc;if(s_eo&&o==s_eo){while(o&&
!n&&t!='BODY'){o=o.parentElement?o.parentElement:o.parentNode;if(!o)
return '';t=s_ot(o);n=s_oid(o);x=o.s_oidt}oc=o.onclick?
o.onclick.toString():'';if(oc.indexOf("s_gs(")>=0)return ''}ta=
o.target;h=o.href?o.href:'';i=h.indexOf('?');h=s_gg(
'linkLeaveQueryString')||i<0?h:h.substring(0,i);l=s_gg('linkName')?
s_gg('linkName'):s_ln(h);t=s_gg('linkType')?s_gg('linkType'
).toLowerCase():s_lt(h);if(t&&(h||l))q+='&pe=lnk_'+(t=='d'||t=='e'?
s_ape(t):'o')+(h?'&pev1='+s_ape(h):'')+(l?'&pev2='+s_ape(l):'');else
trk=0;if(s_gg('trackInlineStats')){if(!p){p=s_gv('pageURL');w=0}t=
s_ot(o);i=o.sourceIndex;if(s_gg('objectID')){n=s_gg('objectID');x=1;i=
1}if(p&&n&&t)qs='&pid='+s_ape(s_fl(p,255))+(w?'&pidt='+w:'')+'&oid='
+s_ape(s_fl(n,100))+(x?'&oidt='+x:'')+'&ot='+s_ape(t)+(i?'&oi='+i:'')}
}if(!trk&&!qs)return '';if(trk)q=(vt?'&t='+s_ape(vt):'')+s_hav()+q
s_wd.s_linkName=s_wd.s_linkType=s_wd.s_objectID=s_lnk=s_eo='';if(
!s_wd.s_disableLegacyVars)s_wd.linkName=s_wd.linkType=s_wd.objectID=''
var code='';if(un){if(trk&&s_vs(un,sed))code+=s_mr(un,sess,q+(qs?qs:
s_rq(un)),ta);s_sq(un,trk?'':qs)}else if(s_wd.s_unl)
for(var unn=0;unn<s_wd.s_unl.length;unn++){un=s_wd.s_unl[unn];if(trk&&
s_vs(un,sed))code+=s_mr(un,sess,q+(qs?qs:s_rq(un)),ta);s_sq(un,trk?'':
qs)}return code}function s_dc(un){un=un.toLowerCase();var dyas=s_gg(
'dynamicAccountSelection'),dyal=s_gg('dynamicAccountList'),dyam=s_gg(
'dynamicAccountMatch');if(dyas&&dyal)un=s_dyas(un,dyal,dyam);s_wds(un)
s_ca(un);return s_gs(un)}
s_code=s_dc(s_account);if(s_code)s_d.write(s_code)