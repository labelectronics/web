//<!-- Begin

function popUpNoScroll(URL) {
	eval("page" + " = window.open(URL, '" + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=1,resizable=1,width=700,height=450');");
}

function popUpScroll(URL) {
	eval("page" + " = window.open(URL, '" + "', 'toolbar=1,scrollbars=1,location=0,statusbar=0,menubar=1,resizable=1,width=714,height=450');");
}

// general popups
function popUp(url) {
	var popWindow = window.open(url,'pop','width=650,height=400,top=167,left=165,menubar,status,scrollbars,resizable,toolbar,location');
	popWindow.focus();
}

// popup for signal chains
function popUpSC(url,windowName) {
	var popWindow = window.open(url,windowName,'width=550,height=270,top=167,left=165,scrollbars,resizable');
	popWindow.focus();
}

// popup for Rate this Page
function popUpRate(url) {
	var popWindow = window.open(url,'pop','width=780,height=600,top=60,left=120,menubar,status,scrollbars,resizable,toolbar,location');
	popWindow.focus();
}

function popUpScrollAll(URL) {
	eval("page" + " = window.open(URL, '" + "', 'menubar,status,scrollbars,resizable,toolbar,location,width=730,height=500');");
}

function popUpNoScroll2(URL) {
	eval("page" + " = window.open(URL, '" + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=1,resizable=1,width=700,height=400');");
}

function sendToCart(theForm, Mode, Model){
	if(Mode != "" && Model != ""){
		theForm.Action.value = Mode;
		theForm.ModelNbr.value = Model;
		theForm.submit();
	}
}

function sendToCartinNewWin(theForm, Mode, Model){
	window.open('','NewWin') 
	if(Mode != "" && Model != ""){
		theForm.Action.value = Mode;
		theForm.ModelNbr.value = Model;
		theForm.target = 'NewWin';
		theForm.submit();
	}
}

function printerFriendly(){
	if(document.getElementById("header")) document.getElementById("header").style.display = "none";
	if(document.getElementById("footer")) document.getElementById("footer").style.display = "none";
	if(document.getElementById("leftNav")) document.getElementById("leftNav").style.display = "none";
	if(document.getElementById("breadcrumb")) document.getElementById("breadcrumb").style.display = "none";
	if(document.getElementById("rightNav")) document.getElementById("rightNav").style.display = "none";
	if(document.getElementById("leftNav2")) document.getElementById("leftNav2").style.display = "none";
	if(document.getElementById("centerSection")) document.getElementById("centerSection").style.width="600px";

	window.print()

	if(document.getElementById("rightNav")) document.getElementById("rightNav").style.display = "block";
	if(document.getElementById("leftNav")) document.getElementById("leftNav").style.display = "block";
	if(document.getElementById("breadcrumb")) document.getElementById("breadcrumb").style.display = "block";
	if(document.getElementById("header")) document.getElementById("header").style.display = "block";
	if(document.getElementById("footer")) document.getElementById("footer").style.display = "block";
	if(document.getElementById("leftNav2")) document.getElementById("leftNav2").style.display = "block";
	if(document.getElementById("centerSection")) document.getElementById("centerSection").style.width="705px";
}

function setUpInitialStylesheet() {
	var i, a, main;
	for (i=0; (a = document.getElementsByTagName("link")[i]); i++) {
		if (a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title")) {
			a.disabled = true;
			if (a.getAttribute("title") == 'main') a.disabled = false;
			if (a.getAttribute("title") == 'printerfriendly') a.disabled = true;
		}
	}
}

function setActiveStyleSheet(title) {
	var i, a, main;
	for (i=0; (a = document.getElementsByTagName("link")[i]); i++) {
		if (a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title")) {
			//a.disabled = true;
			if (a.getAttribute("title") == title) a.disabled = false;
		}
	}

	window.print()

	for (i=0; (a = document.getElementsByTagName("link")[i]); i++) {
		if (a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title")) {
			a.disabled = false;
			if (a.getAttribute("title") == title) a.disabled = true;
		}
	}
}

function submitToPopUp (objForm, strFeatures, strWindowName) {
	 if (!strWindowName)
	    strWindowName = 'formTarget' + (new Date().getTime());
	 objForm.target = strWindowName;
	 window.open('', strWindowName, strFeatures);
}
	
function agreement_check(id) {
 	var styleDiv=document.getElementById(id).style;
 	if (document.requestForm.chkAgreement.checked) {
		styleDiv.visibility ='visible';
		document.requestForm.chkAgreement.disabled=true;
 	} else {
 		alert("You have to accept the terms and conditions to proceed ahead");
 	}
}

function popup_releaseagreement(URL, Title, Wdth, Hght) {
	 var leftVal = (screen.width/2) - (Wdth/2); 
	 var topVal = (screen.height/2) - (Hght/2); 
	 window.open(URL,Title,"width=" + Wdth + ",height=" + Hght + ",top="+ topVal +",left=" + leftVal + ",toolbar=no,menubar=no,scrollbars=yes");
}

function printerPricePkg(id) {
  if (document.all && window.print) {
	var div2print = document.all[id];
	var divs = document.all.tags('div');
	
	for (var d = 0; d < divs.length; d++) {
		 if (divs[d] != div2print)
			divs[d].style.display = 'none';
	}	
	window.print();
	
	for (var e = 0; e < divs.length; e++)
       divs[e].style.display = 'block';
  	}
}
			 
// End -->
