var i =0;//Define a page level variable for setting the threshold limit of the Ajax call checks

function validateAjaxCallCount(jsPath,omnitureStatus,eloquaStatus,googleStatus){
	if (i>=2){
		callAnalytics(jsPath,omnitureStatus,eloquaStatus,googleStatus);
	} else {
		if (ajaxCount <= 0)	{
			//alert("INSIDE AJAX COUNT");
			callAnalytics(jsPath,omnitureStatus,eloquaStatus,googleStatus);
		}
		else {
			i = i+1;
			window.setTimeout('testDelay("'+ jsPath + '","' + omnitureStatus + '","' + eloquaStatus + '","' + googleStatus +'")',2000); //this would be my fictional function to delay the loop
		}
	}
	return true;
}

function testDelay(jsPath,omnitureStatus,eloquaStatus,googleStatus){
	validateAjaxCallCount(jsPath,omnitureStatus,eloquaStatus,googleStatus);
}

function callAnalytics(jsPath,omnitureStatus,eloquaStatus,googleStatus){
	loadAnalytics(jsPath,omnitureStatus,eloquaStatus,googleStatus);
}

function loadAnalytics(jsPath,omnitureStatus,eloquaStatus,googleStatus) {
var scirptTags = "";

if (eloquaStatus == 'true'){
	scirptTags += "<script type='text/javascript' src='"+jsPath+"eloqua/elqCfg.js'></script>";
	scirptTags += "<script type='text/javascript' src='"+jsPath+"eloqua/elqImg.js'></script>";
}

/* Site-redesign: commented as code moved to site footers as part of  web analytics changes */
/*if (googleStatus == 'true'){
	scirptTags += "<title>" + document.title + "</title>";
	scirptTags += "<!-- Google Analytics -->";
	scirptTags += "<script type=\"text/javascript\">";
	scirptTags += "var gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");";
	scirptTags += "document.write(unescape(\"%3Cscript src='\" + gaJsHost + \"google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E\"));</script>";
	scirptTags += "<script type=\"text/javascript\">document.write(unescape(\"%3Cscript src='" + jsPath + "js/googleAnalytics.js' type='text/javascript'%3E%3C/script%3E\"));</script>";
	scirptTags += "<!--/ Google Analytics -->";
}*/

var oFrame = document.getElementById( "testFrame" ); 
var doc = oFrame.contentDocument;
if (doc == undefined || doc == null)
    doc = oFrame.contentWindow.document;
doc.open();
doc.write(scirptTags);

doc.close();
oFrame.visible=false;
}







