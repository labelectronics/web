/******************************************************************************************************
 * Mod Log
 * Version  Author                Date          Description
 *  1.0     Infosys Offshore    Dec 21, 2007
 *  2.0     Guravaiah_P         Aug 29, 2008    includeEloquaLibrary() -- Added for Eloqua Implementation
 * 
******************************************************************************************************/

//onfocus clears the 'searchbox' default text in the header.
function clear_resources_textbox(){
    if (document.getElementById("searchbox1").value == "Search") {
        document.getElementById("searchbox1").value = "";
    }
}


Array.prototype.contains = function (element){
    for (var i = 0; i < this.length; i++)
    {
        if (this[i] == element)
        {
            return true;
        }
    }
    return false;
}

Array.prototype.indexOf = function ( element) {
    for (var i = 0; i < this.length; i++)
    {
        if (this[i] == element)
        {
            return i;
        }
    }
    return -1;
}

String.prototype.trim = function () {
    return this.replace(/^\s*/, "").replace(/\s*$/, "");
}

function getpos(divid) {
var offsetTrail = document.getElementById(divid);
var offsetLeft = 0;
var offsetTop = 0;

while (offsetTrail) {
    offsetLeft += offsetTrail.offsetLeft;
    offsetTop += offsetTrail.offsetTop;
    offsetTrail = offsetTrail.offsetParent;
    }
    return {
        left:offsetLeft,top:offsetTop
    }
}

function loadPopupContent() {
    // Assuming that the parent opener has passed the div id as window name
    var pdiv = window.opener.document.getElementById(window.name);
    var cdiv = document.getElementById("popup_content_new");
    var bodyContent = pdiv.innerHTML;
    bodyContent += "<iframe id='testFrame' src='' height='0px' visible='false' border='0px' style='display:none;'></iframe>";
    cdiv.innerHTML = bodyContent;
}

function loadPopupTitle() {
    // Assuming that the parent opener has passed the div id as window name
    var substringWinName = "";
    var winName = window.name;
    substringWinName = winName.substring(0,13);

    var winNameArray = new Array();
    winNameArray = winName.split('_');
    var pCont = window.opener.document.getElementById(substringWinName).getElementsByTagName("h3")[0];
    var pSpan = window.opener.document.getElementById(substringWinName).getElementsByTagName("h3")[0].getElementsByTagName("span")[0];
    var cCont = document.getElementsByTagName("h1")[0];

    var h1Text = pCont.childNodes[0].data;
    if ("MN" == winNameArray[3]) {
        h1Text = h1Text.split(":")[0];
    }
    
    var h1TextNode = document.createTextNode(h1Text);
    if(pSpan)
    {
    var h1SpanText = pSpan.childNodes[0].data;
    cSpanText = document.createTextNode(h1SpanText.trim());
    var newspanelement = document.createElement("span");
    newspanelement.appendChild(cSpanText);
    }
    else
    {
        var h1SpanText = "";
        cSpanText = document.createTextNode(h1SpanText);
        var newspanelement = document.createElement("span");
        newspanelement.appendChild(cSpanText);
    }
    
        if(cCont.childNodes[0]!= undefined)
        {
            var brElement = document.createElement("br");
            newspanelement.appendChild(brElement);
            brElement = document.createElement("br");
            newspanelement.appendChild(brElement);
            
            var h1SpanText1 =cCont.childNodes[0].data;
            catSpanText = document.createTextNode(h1SpanText1.trim());
            newspanelement.appendChild(catSpanText);
            
            var newdivelement = document.createElement("div");
            newdivelement.appendChild(h1TextNode);
            
            newdivelement.appendChild(newspanelement);
            //cCont.removeChild(cCont.firstChild);    
            while (cCont.firstChild) 
            {
                cCont.removeChild(cCont.firstChild);
            }
            
            cCont.appendChild(newdivelement);
        }
        else
        {
    cCont.appendChild(h1TextNode);
    
    if ("MN" == winNameArray[3]) {
        var brElement = document.createElement("br");
        cCont.appendChild(brElement);
    }
    cCont.appendChild(newspanelement);
}
}


function validateForm() {
    alertMsg = "";
    errorMsg = "";
    var F_Format;
    var strFFormat = "";
    var S_Format;
    var strSFormat = "";

    if((document.getElementById('chkSymbolId').checked == false) && (document.getElementById('chkFootprintId').checked == false)) {
        alertMsg += "- Please check atleast one of the requests\n";
    }

    //if ((document.getElementById('requestedFormat').value.trim().length > 0) && (document.getElementById('userEmailId').value.trim().length > 0))
    if (document.getElementById('userEmailId').value.trim().length > 0)
    {
        //NCH_textCheck(document.getElementById('requestedFormat').value.trim(), 1, "- Requested Format\n");
        NCH_textCheck(document.getElementById('userEmailId').value.trim(), 1, "- Email\n");

        // Check field format
        NCH_emailCheck(document.getElementById('userEmailId').value.trim(), "- Email: check for @s, special characters, domain name etc\n");
    }
    else
    {
        if (document.getElementById('userEmailId').value.trim().length == 0)
        {

            alertMsg += "- Email is a required field\n";
        }
        
    }
    var Smsg = false;
    if(document.getElementById('chkSymbolId').checked == true) {
        for (var intSLoop=0; intSLoop < document.getElementById('S_requestedFormat').length; intSLoop++)
        {
            if(document.getElementById('S_requestedFormat').options[intSLoop].selected)
            {
                Smsg = true;
                break;
            }
        }
    }

    var Fmsg = false;
    if(document.getElementById('chkFootprintId').checked == true) {
        for (var intFLoop=0; intFLoop < document.getElementById('F_requestedFormat').length; intFLoop++)
        {
            if(document.getElementById('F_requestedFormat').options[intFLoop].selected)
            {
                Fmsg = true;
                break;
            }
        }
    }

    if (Smsg == false && Fmsg==false)
        {
            alertMsg += "- Requested Format is a required field\n";
        }

    if (alertMsg.length > 0)
    {
        errorMsg += "\n\nThe following field(s) contain invalid data:\n\n";
        errorMsg += alertMsg;
        return false;
    }
    else
    {
        if(document.getElementById('chkFootprintId').checked == true) {
            F_Format = document.getElementById('F_requestedFormat');
            if(null != F_Format) {
                var fFormatLength = F_Format.length;
                if(null != fFormatLength) {
                    var strFFormat = "";
                    for(var i = 0; i < fFormatLength; i++) {
                        var optionF = F_Format.options[i].value;
                        if(null != optionF && F_Format.options[i].selected) {
                            if(strFFormat == "") {
                                strFFormat += optionF;
                            }
                            else {
                                strFFormat += ", " + optionF;
                            }
                        }
                    }
                }
            }
        }
        if(document.getElementById('chkSymbolId').checked == true) {
            S_Format = document.getElementById('S_requestedFormat');
            if(null != S_Format) {
                var sFormatLength = S_Format.length;
                if(null != sFormatLength) {
                    strSFormat = "";
                    for(var i = 0; i < sFormatLength; i++) {
                        var optionS = S_Format.options[i].value;
                        if(null != optionS && S_Format.options[i].selected) {
                            if(strSFormat == "") {
                                strSFormat += optionS;
                            }
                            else {
                                strSFormat += ", " + optionS;
                            }
                        }
                    }
                }
            }
        }
        // Set the value in a hidden field depending upon the condition
        if(strSFormat != "" && strFFormat == "") {
            document.getElementById('requestedFormat').value = strSFormat;
        }
        if(strSFormat == "" && strFFormat != "") {
            document.getElementById('requestedFormat').value = strFFormat; // Set the value in a hidden field.
        }
        if(strSFormat != "" && strFFormat != ""){
            document.getElementById('requestedFormat').value = strSFormat + " & " + strFFormat + " respectively"; // Set the value in a hidden field.
        }

        return true;
    }
}

 String.prototype.trim = function()
  {

 // skip leading and trailing whitespace
 // and return everything in between
  var x=this;
  x=x.replace(/^\s*(.*)/, "$1");
  x=x.replace(/(.*?)\s*$/, "$1");
  return x;
  }

//TextCheck function for required fields
function NCH_textCheck(line, len, name)
 {
     if (line.length < len) {
        alertMsg += name
        return false;
     } else {
        return true;
    }
}

//email validation
function NCH_emailCheck(emailStr, name) {
    /* The following variable tells the rest of the function whether or not
    to verify that the address ends in a two-letter country or well-known
    TLD.  1 means check it, 0 means don't. */

    var checkTLD=1;

    /* The following is the list of known TLDs that an e-mail address must end with. */

    var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;

    /* The following pattern is used to check if the entered e-mail address
    fits the user@domain format.  It also is used to separate the username
    from the domain. */

    var emailPat=/^(.+)@(.+)$/;

    /* The following string represents the pattern for matching all special
    characters.  We don't want to allow special characters in the address.
    These characters include ( ) < > @ , ; : \ " . [ ] */

    var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]>";

    /* The following string represents the range of characters allowed in a
    username or domainname.  It really states which chars aren't allowed.*/

    var validChars="\[^\\s" + specialChars + "\]";

    /* The following pattern applies if the "user" is a quoted string (in
    which case, there are no rules about which characters are allowed
    and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
    is a legal e-mail address. */

    var quotedUser="(\"[^\"]*\")";

    /* The following pattern applies for domains that are IP addresses,
    rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
    e-mail address. NOTE: The square brackets are required. */

    var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;

    /* The following string represents an atom (basically a series of non-special characters.) */

    var atom=validChars + '+';

    /* The following string represents one word in the typical username.
    For example, in john.doe@somewhere.com, john and doe are words.
    Basically, a word is either an atom or quoted string. */

    var word="(" + atom + "|" + quotedUser + ")";

    // The following pattern describes the structure of the user

    var userPat=new RegExp("^" + word + "(\\." + word + ")*$");

    /* The following pattern describes the structure of a normal symbolic
    domain, as opposed to ipDomainPat, shown above. */

    var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");

    /* Finally, let's start trying to figure out if the supplied address is valid. */

    /* Begin with the coarse pattern to simply break up user@domain into
    different pieces that are easy to analyze. */

    var matchArray=emailStr.match(emailPat);

    if (matchArray==null) {

    /* Too many/few @'s or something; basically, this address doesn't
    even fit the general mould of a valid e-mail address. */
    alertMsg += name
    return false;
    }

    var user=matchArray[1];
    var domain=matchArray[2];

    // Start by checking that only basic ASCII characters are in the strings (0-127).

    for (i=0; i < user.length; i++) {
    if (user.charCodeAt(i) > 127) {
    alertMsg += name
    return false;
       }
    }
    for (i=0; i < domain.length; i++) {
    if (domain.charCodeAt(i) > 127) {
    alertMsg += name
    return false;
       }
    }

    // See if "user" is valid

    if (user.match(userPat)==null) {

    // user is not valid

    alertMsg += name
    return false;
    }

    /* if the e-mail address is at an IP address (as opposed to a symbolic
    host name) make sure the IP address is valid. */

    var IPArray=domain.match(ipDomainPat);
    if (IPArray!=null) {

    // this is an IP address

    for (var i=1;i<=4;i++) {
    if (IPArray[i]>255) {
    alertMsg += name
    return false;
       }
    }
    return true;
    }

    // Domain is symbolic name.  Check if it's valid.

    var atomPat=new RegExp("^" + atom + "$");
    var domArr=domain.split(".");
    var len=domArr.length;
    for (i=0;i < len;i++) {
    if (domArr[i].search(atomPat)==-1) {
    alertMsg += name
    return false;
       }
    }

    /* domain name seems valid, but now make sure that it ends in a
    known top-level domain (like com, edu, gov) or a two-letter word,
    representing country (uk, nl), and that there's a hostname preceding
    the domain or country. */

    if (checkTLD && domArr[domArr.length-1].length!=2 &&
    domArr[domArr.length-1].search(knownDomsPat)==-1) {
    alertMsg += name
    return false;
    }

    // Make sure there's a host name preceding the domain.

    if (len < 2) {
    alertMsg += name
    return false;
    }

    // If we've gotten this far, everything's valid!
    return true;

}

/* function show_hide_popup(divid,action,tablenum) {

tablenum = tablenum || "1";

if (document.getElementById)
    {
        var mystyle = document.getElementById(divid).style;
        if (action=="show") {

            if (divid=="tablehelp_popup") {
                var tableid = "table"+tablenum;
                var t = getpos(tableid).top + 20;
                var l = getpos(tableid).left + 200;
                mystyle.top = t+"px";
                mystyle.left = l+"px";
            }
            mystyle.display = "block";

        }
        else if (action=="hide") {
            mystyle.display = "none";
        }
    }
    else if (document.all)
    {
        var mystyle = document.all[divid].style;
        if (action=="show") {
            mystyle.display = "block";
        }
        else if (action=="hide") {
            mystyle.display = "none";
        }
    }
} */

function show_hide_popup(divid,action,tablenum) {       /* Modified -- Uncommented if((action=="show") */

tablenum = tablenum || "1";

if (document.getElementById)
    {
        var mystyle = document.getElementById(divid).style;
        
        if (action=="show") {

            if (divid=="tablehelp_popup") {
                var tableid = "table"+tablenum;
                var t = getpos(tableid).top + 20;
                var l = getpos(tableid).left+2;
                mystyle.top = t+"px";
                mystyle.left = l+"px";
                mystyle.height = "343px";
            }
            mystyle.display = "block";

        }
        else if (action=="hide") {
            mystyle.display = "none";
        }
    }
    else if (document.all)
    {
        var mystyle = document.all[divid].style;
        if (action=="show") {
            mystyle.display = "block";
        }
        else if (action=="hide") {
            mystyle.display = "none";
        }
    }
}

function toggleinput(colnum) {

    var enterbtn = "enter_"+colnum;
    var inputfield = "input_"+colnum;

    if (document.getElementById) {
            var actbtnstyle = document.getElementById(enterbtn).style;
            var actinputstyle = document.getElementById(inputfield).style;

            for (var x = 0; x <= 6; x++) {
                if (colnum == x) {
                    actbtnstyle.display = "none";
                    actinputstyle.display = "block";
                } else {
                    enterbtn = "enter_"+x;
                    enterstyle = document.getElementById(enterbtn).style;

                    inputfield = "input_"+x;
                    inputstyle = document.getElementById(inputfield).style;

                    enterstyle.display = "block";
                    inputstyle.display = "none";
                }
            }
    }
}

// toggle tabs
function toggletab(imagePathPrefix, divid) {        /* Modified for product page */

var subcattabs = false;
var catonlytabs = false;
var prodtabs = false;
var pkgtabs = false;
var doubleprodtabs = false;
var doublesubcattabs = false;

if (divid.indexOf('double_subcat_')  > -1) {
    var tabids = new Array ('double_subcat_tab1content', 'double_subcat_tab2content');
    var tabs = document.getElementById("double_subcat_tabbar").style;
    doublesubcattabs = true;
    }
    else if (divid.indexOf('subcat_') > -1) {
    var tabids = new Array ('subcat_tab1content', 'subcat_tab2content', 'subcat_tab3content');
    var tabs = document.getElementById("product_subcat_tabbar").style;
    subcattabs = true;
    }
    else if (divid.indexOf('catonly_')  > -1) {
    var tabids = new Array ('catonly_tab1content', 'catonly_tab2content', 'catonly_tab3content');
    var tabs = document.getElementById("product_catonly_tabbar").style;
    catonlytabs = true;
    }
    else if (divid.indexOf('product_') > -1) {
    var tabids = new Array ('product_tab1content', 'product_tab2content', 'product_tab3content');
    var tabs = document.getElementById("product_tabbar").style;
    prodtabs = true;
    }
    else if (divid.indexOf('pkg_')  > -1) {
    var tabids = new Array ('pkg_tab1content', 'pkg_tab2content');
    var tabs = document.getElementById("pkg_tabbar").style;
    pkgtabs = true;
    }
    else if (divid.indexOf('double_')  > -1) {
    var tabids = new Array ('double_tab1content', 'double_tab2content');
    var tabs = document.getElementById("double_prod_tabbar").style;
    doubleprodtabs = true;
    }

var tabstyle = "";

    if (document.getElementById) {
        for (var i = 0; i < tabids.length; i++) {
            tabstyle = document.getElementById(tabids[i]).style;
                if (divid == tabids[i]) {
                    tabstyle.display = "block";
                        if (prodtabs) {
                            if (i==0) {tabs.background = "url('" + imagePathPrefix + "/images/tabs.gif') 0px 0px";}
                            if (i==1) {tabs.background = "url('" + imagePathPrefix + "/images/tabs.gif') 0px -32px";}
                            if (i==2) {tabs.background = "url('" + imagePathPrefix + "/images/tabs.gif') 0px -64px";}
                        } else if (subcattabs) {
                            if (i==0) {tabs.background = "url('" + imagePathPrefix + "/images/subcat_tabs.gif') 0px 0px";}
                            if (i==1) {tabs.background = "url('" + imagePathPrefix + "/images/subcat_tabs.gif') 0px -32px";}
                            if (i==2) {tabs.background = "url('" + imagePathPrefix + "/images/subcat_tabs.gif') 0px -64px";}
                        } else if (catonlytabs) {
                            if (i==0) {tabs.background = "url('" + imagePathPrefix + "/images/catonly_tabs.gif') 0px 0px";}
                            if (i==1) {tabs.background = "url('" + imagePathPrefix + "/images/catonly_tabs.gif') 0px -32px";}
                            if (i==2) {tabs.background = "url('" + imagePathPrefix + "/images/catonly_tabs.gif') 0px -64px";}
                        }
                        else if (pkgtabs) {
                            if (i==0) {tabs.background = "url('" + imagePathPrefix + "/images/catonly_tabs_two.gif') 0px 0px";}
                            if (i==1) {tabs.background = "url('" + imagePathPrefix + "/images/catonly_tabs_two.gif') 0px -32px";}
                        }
                        else if (doubleprodtabs) {
                            if (i==0) {tabs.background = "url('" + imagePathPrefix + "/images/tabs_two.gif') 0px 0px";}
                            if (i==1) {
                                tabs.background = "url('" + imagePathPrefix + "/images/tabs_two.gif') 0px -32px";
                            }
                        }
                        else if (doublesubcattabs) {
                            if (i==0) {tabs.background = "url('" + imagePathPrefix + "/images/subcat_tabs_two.gif') 0px 0px";}
                            if (i==1) {tabs.background = "url('" + imagePathPrefix + "/images/subcat_tabs_two.gif') 0px -32px";}
                        }
                } else {
                    tabstyle.display = "none"
                }
            }
        } else if (document.all) {
        // for IE5
    }
}

/* Offshore: Changed for home page */
/*function togglebigtab(pathPrefix, num) {

    if (document.getElementById) {
        for (var i = 1; i < 4; i++) {
                if (i == num) {
                    var tabid = "bigtab"+num;
                    var contentid = "tabcontent"+num;

                    tabstyle = document.getElementById(tabid).style;
                    contentstyle = document.getElementById(contentid).style;
                    containerstyle = document.getElementById("bigtabs_container").style;

                    if (num==1) {
                        containerstyle.background = "url('" + pathPrefix + "/images/bigtabs.gif') 0px 0px";
                        mytabtitle = document.getElementById("tab1title");
                        mytabtitle.className= "activetabtitle";

                        mytabinner = document.getElementById("tab1inner1").style;
                        mytabinner.display = "block";
                        mytabinner = document.getElementById("tab1inner2").style;
                        mytabinner.display = "none";

                        mytabinner = document.getElementById("tab2inner1").style;
                        mytabinner.display = "none";
                        mytabinner = document.getElementById("tab2inner2").style;
                        mytabinner.display = "block";

                        mytabinner = document.getElementById("tab3inner1").style;
                        mytabinner.display = "none";
                        mytabinner = document.getElementById("tab3inner2").style;
                        mytabinner.display = "block";

                        mytabtitle = document.getElementById("tab2title");
                        mytabtitle.className= "tabtitle";
                        mytabtitle = document.getElementById("tab3title");
                        mytabtitle.className= "tabtitle";

                        mynavdiv = document.getElementById("nav2").style;
                        mynavdiv.display = "block";

                        mynavdiv = document.getElementById("techsupportnav").style;
                        mynavdiv.display = "none";
                    }

                    if (num==2) {
                        containerstyle.background = "url('" + pathPrefix + "/images/bigtabs.gif') 0px -120px";
                        mytabtitle = document.getElementById("tab2title");
                        mytabtitle.className= "activetabtitle";
                        //
                        mytabinner = document.getElementById("tab1inner1").style;
                        mytabinner.display = "none";
                        mytabinner = document.getElementById("tab1inner2").style;
                        mytabinner.display = "block";

                        mytabinner = document.getElementById("tab2inner1").style;
                        mytabinner.display = "block";
                        mytabinner = document.getElementById("tab2inner2").style;
                        mytabinner.display = "none";

                        mytabinner = document.getElementById("tab3inner1").style;
                        mytabinner.display = "none";
                        mytabinner = document.getElementById("tab3inner2").style;
                        mytabinner.display = "block";

                        mytabtitle = document.getElementById("tab1title");
                        mytabtitle.className= "tabtitle";
                        mytabtitle = document.getElementById("tab3title");
                        mytabtitle.className= "tabtitle";

                        mynavdiv = document.getElementById("nav2").style;
                        mynavdiv.display = "block";

                        mynavdiv = document.getElementById("techsupportnav").style;
                        mynavdiv.display = "none";
                    }

                    if (num==3) {
                        containerstyle.background = "url('" + pathPrefix + "/images/bigtabs.gif') 0px -240px";
                        mytabtitle = document.getElementById("tab3title");
                        mytabtitle.className= "activetabtitle";

                        mytabinner = document.getElementById("tab1inner1").style;
                        mytabinner.display = "none";
                        mytabinner = document.getElementById("tab1inner2").style;
                        mytabinner.display = "block";

                        mytabinner = document.getElementById("tab2inner1").style;
                        mytabinner.display = "none";
                        mytabinner = document.getElementById("tab2inner2").style;
                        mytabinner.display = "block";

                        mytabinner = document.getElementById("tab3inner1").style;
                        mytabinner.display = "block";
                        mytabinner = document.getElementById("tab3inner2").style;
                        mytabinner.display = "none";

                        mytabtitle = document.getElementById("tab1title");
                        mytabtitle.className= "tabtitle";
                        mytabtitle = document.getElementById("tab2title");
                        mytabtitle.className= "tabtitle";

                        mynavdiv = document.getElementById("nav2").style;
                        mynavdiv.display = "none";

                        mynavdiv = document.getElementById("techsupportnav").style;
                        mynavdiv.display = "block";
                    }

                    contentstyle.display = "block";
                } else {
                    var contentid = "tabcontent"+i;
                    contentstyle = document.getElementById(contentid).style;
                    contentstyle.display = "none";
                }

        }
    } else if (document.all) {

    }
}*/

function toggleacc(num) {

    if (document.getElementById) {
        for (var i = 1; i < 4; i++) {
                if (i == num) {
                    var accid = "acc"+num;
                    var accontentid = "accontent"+num;

                    accstyle = document.getElementById(accid).style;
                    accontentstyle = document.getElementById(accontentid).style;

                    accontentstyle.display = "block";
                    accstyle.background = "#b9b9b9 url('images/accbg.gif') 220px 0px no-repeat";


                } else {
                    var accontentid = "accontent"+i;
                    var accid = "acc"+i;
                    accstyle = document.getElementById(accid).style;
                    accontentstyle = document.getElementById(accontentid).style;
                    accontentstyle.display = "none";
                    accstyle.background = "#b9b9b9 url('images/accbg.gif') 220px -28px no-repeat";
                }

        }
    } else if (document.all) {

    }
}

// enlarge images in popup window
function enlarge (image, title) {
    var w = screen.width;
    var h = screen.height;
    var l = w/2-300;
    var t = h/2-250;

    //popupwindow= window.open ("images/product/"+image+"", "AnalogDevices", "location=0, status=0, scrollbars=0, width=600, height=500, left="+l+", top="+t+"");
    popupwindow= window.open ("", "AnalogDevices", "location=0, status=0, scrollbars=0, width=600, height=500, left="+l+", top="+t+"");
    popupwindow.document.write("<html><head><title>Analog Devices - "+title+"</title></head><body><img src='/static/images/product/"+image+"' /><br /><br /><h4 align='center'>"+title+"</h4></body></html>");  /* Modified -- Accomodated caption */
}

/* Added for Design Center */
function subItemShowHide(divId,className) {
    var oDiv;
    var uiCtrl;
    var uiChildCtrl;
    var index,ctrlCount;

    oDiv = document.getElementById(divId);

    if(oDiv.className == "divhidestyle"){
      oDiv.className = "divdisplaystyle";
    } else {
      oDiv.className = "divhidestyle";
    }

    uiCtrl = oDiv.parentNode;
    ctrlCount = uiCtrl.childNodes.length;

    for (index=0;index<ctrlCount;index++){
        uiChildCtrl = uiCtrl.childNodes[index]
        if (uiChildCtrl.tagName == 'UL' ){
            if (uiChildCtrl.id != divId && uiChildCtrl.className != className){
                uiChildCtrl.className = "divhidestyle";
            }
        }
    }
}

function clearTxtBox(ctrlID,defaultText) {
    var ctrl;
    ctrl = document.getElementById(ctrlID);
    if (ctrl.value == defaultText){
        ctrl.value = "";
    }
}

function populateTxtBoxDefaultWithValues(ctrlID,defaultText) {
    var ctrl;
    ctrl = document.getElementById(ctrlID);
    if (ctrl.value == ""){
      ctrl.value = defaultText;
    }
}


function subSectionTableShowDetail(divHideId, divShowId, ctrlHideID, ctrlShowID) {
    var oDivHide, oDivShow;
    var ctrlHide, ctrlShow, txtHiddenVal;
    var oDivOld;
    var oDivParent, oDivChild;

    oDivHide = document.getElementById(divHideId);
    oDivShow = document.getElementById(divShowId);

    ctrlHide = document.getElementById(ctrlHideID);
    ctrlShow = document.getElementById(ctrlShowID);

    if(ctrlHide.value != "") {
        txtHiddenVal = ctrlHide.value;
        oDivOld = document.getElementById(txtHiddenVal);
        oDivOld.className = "divhidestyle";

        txtHiddenVal = ctrlShow.value;
        oDivOld = document.getElementById(txtHiddenVal);
        oDivOld.className = "divdisplaystyle";
    }

    oDivHide.className = "divhidestyle";
    oDivShow.className = "divdisplaystyle";
    ctrlHide.value = oDivShow.id;
    ctrlShow.value = oDivHide.id;
}

function subSectionTableHideDetail(divHideId, divShowId) {
    var oDivHide, oDivShow;

    oDivHide = document.getElementById(divHideId);
    oDivShow = document.getElementById(divShowId);

    oDivHide.className = "divhidestyle";
    oDivShow.className = "divdisplaystyle";
}







/*function to update the product rows*/
/*function updateProducts(field,liTagId) {
    var oSpan;
    var j;

    for (i = 0; i < field.length; i++)
    if(field[i].checked == true) {
        j = i + 1;
        oSpan = document.getElementById(liTagId + j);
        oSpan.style.display = "none";
    }
} */



/*Add products on click of add button*/

/*function addProducts(txtBoxId,msgBoxId) {
    var txt;
    var oSpan;
    var msgDiv;
    var cleartxtBox;
    txt = document.getElementById(txtBoxId).value;

    if(txt == 1000) {
        oSpan = document.getElementById("product_li8");
        oSpan.className ="divdisplaystyle";
        msgDiv = document.getElementById(msgBoxId);
        msgDiv.className ="divdisplaystyle";
    } else {
        msgDiv = document.getElementById(msgBoxId);
        msgDiv.className ="divdisplaystyle";
    }
    cleartxtBox = document.getElementById(txtBoxId);
    cleartxtBox.value = "";
}*/
/* End of Design Center functions addition */

/* Print Table */
function printme(evt) {

  var content = document.getElementById(evt).innerHTML;
  src = content;
  link = "about:blank";
  var pw = window.open(link, "_new", "toolbar=0,scrollbars=yes,location=0,statusbar=0,menubar=1,resizable=yes,width=950,height=500");
  pw.document.open();
  pw.document.write(makeIstPage(src, '', '', 'Pricing, Packaging and Availability Table'));
  pw.document.close();

}

function makepage(src) {
  return "<html>\n" +
    "<head>\n" +
    "<title>Pricing, Packaging and Availability Table</title>\n" +
    "<link rel='stylesheet' type='text/css' href='/static/include/styles/table_print.css' />\n" +
    "<script>\n" +
    "function CallPrint() {\n" +
    "  setTimeout('PrintPage()', 2);\n" +
    "}\n" +
    "function PrintPage() {\n" +
    "  window.print();\n" +
    "}\n" +
    "</script>\n" +
    "</head>\n" +
    "<body onLoad='CallPrint()'>\n" +
    "<div id='pricing_table'>" + src + "</div>\n" +
    "</body>\n" +
    "</html>\n";
}
/* End of Print Table */




function SetInitialDisplay()
{

    var hasQueryString = document.URL.indexOf('?printerVersion');
    var src;
    src = "";
    if (hasQueryString != -1) {
        document.getElementById('printerFriendly').style.display = 'none';
        document.getElementById('printImg').style.display = 'block';
        src += "<a name='top'></a>\n";
        /*src += document.getElementById('content').innerHTML;*/
        src += document.getElementsByTagName('body').innerHTML;
        document.getElementById('printDisplay').innerHTML = src;
        /*document.getElementById('header').style.display = 'none';
        document.getElementById('container').style.display = 'none';
        document.getElementById('divFooter').style.display = 'none';*/
        document.getElementById('printDisplay').style.display = 'block';
    }
}

function PrintPage()
{
    document.getElementById('printImg').style.display = 'none';
    window.print();
}

function setHiddenVariable(num)
{
    document.frmStaticLinks.setHidden.value = num;
    document.frmStaticLinks.submit();
    return true;
}

/**
 * Interpolates values from the array 'arr' into the string 'text' in a manner similar to java.text.MessageFormat.
 *
 * text - the format string, for example, "Hello {0}!"
 * arr  - the array of items to be interpolated into the text string, e.g., ["Jim"]
 * returns the text argument with the {0}, {1}, etc. placeholders replaced by values from the arr array.
 */
function msgFormat(text, arr) {
  for (var i=0; i < arr.length; i++) {
    var re = new RegExp('\\{' + i + '\\}', 'g');
    text = text.replace(re, arr[i]);
  }
  return text;
}

/**
 * Searches through all links on a page to determine if the link should be targetted to
 * a new window.  The determination is made by checking if the link's href occurs
 * in the specified list of popups and the occurrence has the value of 1.
 *
 * lookup - the lookup table having the form "path" : 1 or 0.
 * targetName - the value of the target="" attribute in the link
 * returns void (not return value) 
 */
function addTargetToLinks(lookup, targetName) {
    $("a").not("[href^=#]").each(function(i) {
        if (!this.href) {
            return;
        }
        var fromPath = '';
        var tempPath = '';
        var localHost = this.ownerDocument.location.hostname;
        if (this.href.search(/^http/) != -1 && this.href.substr(6, localHost.length + 1).indexOf(localHost) == -1) {
            // external href, use as-is.
            fromPath = this.href;
        } else {
            fromPath = this.pathname.replace(/^\/?en|jp|zh|tw|ru(\/.*)$/, "$1");
        }
        if (fromPath in lookup) {
            var toPath = lookup[fromPath][0];
            if (toPath.search(/^http/) == -1) {
                var locale = 'en';
                var localeMatch = this.pathname.match(/^\/(en|ru|jp|zh|tw)\/.*/);
                if (localeMatch != null) {
                    locale = localeMatch[1];
                }
                toPath = '/' + locale + toPath;
            }
            this.href = toPath;
        }
        
        /* START: WR15200 - POPUP WINDOW CHANGE*/
        tempPath = getTransformedPath(this.href); //CHECK FOR DIRECT URLS OF TYPE HTTP://INVESTOR.COM
        var pathFrom = getTransformedPath(fromPath); // CHECK FOR VIRTUAL URLS
        
        if (this.href in lookup.popups || tempPath in lookup.popups || pathFrom in lookup.popups) {
            this.target = targetName;
        }
        /* END: WR15200 - POPUP WINDOW CHANGE*/
    });
}

/*START: WR15200 - POPUP WINDOW CHANGE*/
function getTransformedPath(hrefPath){
	var hrefVal = hrefPath;	
	var tempPath = '';
	var lastChar = hrefVal.charAt(hrefVal.length-1);
    if (lastChar == '/') {
    	tempPath = hrefVal.substr(0, hrefVal.length-1);
    } else {
    	tempPath = hrefPath;
    }
    return tempPath;
}
/*END: WR15200 - POPUP WINDOW CHANGE*/

function loadSpecificLanguagePage(){
    var LanguageSelect = document.getElementById("language_dropdown");
    if(LanguageSelect.selectedIndex != -1) {
        var sIndex = LanguageSelect.selectedIndex;
        var changeLocale = LanguageSelect[sIndex].value;        
        var currentUrl = window.location.href;       
        var urlSplit = currentUrl.split('/');
        var http=urlSplit[0];
        var locale=urlSplit[3];    
        var changedUrl=currentUrl.replace(locale, changeLocale);
        location.replace(changedUrl);
    }
}

function hideLanguageDropdown(taxonomyName){
    var suppress = "";
    var currentUrl = window.location.href;
    var urlSplit = currentUrl.split('/');
    var htmlType = urlSplit[(urlSplit.length)-1];
    if (htmlType.indexOf('fca.html') > -1){
        suppress = true;}
    if (htmlType.indexOf('docErrata.html') > -1){
        suppress = true;}
    if (htmlType.indexOf('newProd.html') > -1){
        suppress = true;}
    if (htmlType.indexOf('allProd.html') > -1){
        suppress = true;}
    var mystyle = document.getElementById("languagedropdown").style;
    if((taxonomyName == 'home-root'|| taxonomyName =='solutions-root' || taxonomyName =='products-root' || taxonomyName =='vc-listing-root')){      
        if (suppress != true)
        mystyle.display = "block";
        //alert(mystyle.display);
    }
}

 /*print the pop up page*/
/*function printPopupPage() {
    if(document.getElementById("popup")) document.getElementById("popup").style.background="none";
    if(document.getElementById("close")) document.getElementById("close").style.display = "none";
    window.print()          
    setTimeout('displayPopup()', 2500);
}*/

function displayPopup() {
    if(document.getElementById("popup")) document.getElementById("popup").style.background="#FFFFFF url(/static/images/banner_collage.gif) no-repeat scroll right top";
    if(document.getElementById("close")) document.getElementById("close").style.display = "block";
    
}

function validateEmailForm() {
    alertMsg = "";
    errorMsg = "";    
    
    if (document.getElementById('toEmail').value.trim().length > 0)
    {           
        NCH_textCheck(document.getElementById('toEmail').value.trim(), 1, "- Email\n");
        // Check field format
        NCH_emailCheck(document.getElementById('toEmail').value.trim(), "- Email: check for @s, special characters, domain name etc\n");
    }
    else
    {
        if (document.getElementById('toEmail').value.trim().length == 0)
        {
            alertMsg += "- Email is a required field\n";
        }       
    }
    
    if (document.getElementById('fromEmail').value.trim().length > 0)
    {       
        NCH_textCheck(document.getElementById('fromEmail').value.trim(), 1, "- Email\n");
        // Check field format
        NCH_emailCheck(document.getElementById('fromEmail').value.trim(), "- Email: check for @s, special characters, domain name etc\n");
    }
    else
    {
        if (document.getElementById('fromEmail').value.trim().length == 0)
        {
            alertMsg += "- Email is a required field\n";
        }       
    }
    
    
    if (alertMsg.length > 0)
    {
        errorMsg += "\n\nThe following field(s) contain invalid data:\n\n";
        errorMsg += alertMsg;
        alert(errorMsg);
        return false;
    }
    else{
        var currentUrl = window.opener.location;        
        document.getElementById('emailOpenerUrl').value = currentUrl ;              
        return true;
    }
    
}

function contentResize(){
    var bTryAgain = true;
    //CHECK IF THE IFRAME HAS LOADED AND RESIZECROSSSELLFRAME FUNCTION IS AVAILABLE.
    if(typeof(document.getElementById('content_frame').contentWindow)== 'object'){
        if(typeof(document.getElementById('content_frame').contentWindow.resizeCrossSellFrame) == 'function'){
            bTryAgain = false;
        }
    }
    //IF IFRAME'S DOCUMENT HAS LOADED AND INTERNAL JS FUNCTION IS AVAILABLE, CALL IT
    //OTHERWISE, WAIT AND TRY AGAIN
    if(bTryAgain){
        setTimeout("contentResize()",2000);
    }
    else
    {
        document.getElementById('content_frame').contentWindow.resizeCrossSellFrame();
    }
}

function setProdSearchAction(locale)
{
    var redirectUrl;
    var product = document.getElementById('searchbox1').value;
    redirectUrl = '/' + locale + '/' + product + '/productSearch.html';
    document.searchform1.action = redirectUrl;
    document.searchform1.submit();
}

/* Start: Glossary of term*/
var xCoord;
var yCoord;
/* Start Modification for Glossary changes - 9.2.2 */
function viewGlossary(glossaryTerm, pronounceStatus, locale) {
    show_glossary('', glossaryTerm, '', pronounceStatus, locale);
}

function show_glossary(event, glossaryTerm, colFlag, pronounceStatus, locale){
    var currentUrl = window.location.href;
    var urlSplit = currentUrl.split('/');
    var page_locale = urlSplit[3];
    if (event != '') {
        populateCoords(event, locale);
    }
    var ajaxPath = "/glossaryTerm.html?glossaryTerm=" + glossaryTerm + '&locale=' + locale + '&pronounceStatus=' + pronounceStatus;
    $.ajax({
        type:"GET",
        url: ajaxPath,
        success: function(html) {
            quickViewGlossaryTerm(html, glossaryTerm, locale, colFlag);
        },
        dataType: "html",
        error: function(x,s,e) {
            glossaryTermError(x, s, e)
        }
    });
}

function populateCoords(event, page_locale) {
    if (!event) {
        event = window.event;
    }
    if( typeof( event.pageX ) == 'number' ) {
        //most browsers
        xCoord = event.pageX;
        yCoord = event.pageY -25;
        if (page_locale == 'jp')
            yCoord -= 17;
    } else if( typeof( event.clientX ) == 'number' ) {
        //Internet Explorer and older browsers
        //other browsers provide this, but follow the pageX/Y branch
        xCoord = event.clientX;
        yCoord = event.clientY -25;
        var badOldBrowser = ( window.navigator.userAgent.indexOf( 'Opera' ) + 1 ) ||
          ( window.ScriptEngine && ScriptEngine().indexOf( 'InScript' ) + 1 ) ||
          ( navigator.vendor == 'KDE' );
        if( !badOldBrowser ) {
          if( document.body && ( document.body.scrollLeft || document.body.scrollTop ) ) {
            //IE 4, 5 & 6 (in non-standards compliant mode)
            xCoord += document.body.scrollLeft;
            yCoord += document.body.scrollTop;
          } else if( document.documentElement && ( document.documentElement.scrollLeft || document.documentElement.scrollTop ) ) {
            //IE 6 (in standards compliant mode)
            xCoord += document.documentElement.scrollLeft;
            yCoord += document.documentElement.scrollTop;
          }
        }
        if (page_locale == 'jp' && $.browser.version == "6.0") {
            yCoord = yCoord -15;
        }
    }
}

function showGlossaryTerms_ByIndex(indexLetter, locale){
    var currentUrl = window.location.pathname;
    var urlSplit = currentUrl.split('/');
    var language = urlSplit[1];
    var changedUrl=currentUrl.replace(language, locale);
    var ajaxPath = changedUrl+ "?indexLetter=" + encodeURIComponent(indexLetter);
    $.ajax({
        type:"GET",
        url: ajaxPath,
        success: function(html) {
            displayGlossaryTermsByIndex(html);
        },
        dataType: "html",
        error: function(x,s,e) {
            glossaryTermError(x, s, e)
        }
    });
}

function displayGlossaryTermsByIndex(html){
    $('#Gloss').remove();
    $("div#glossaryTerms").html(html);
}

var secondLink;
var links = new Array();

/**
 * JQuery-style CSS object used in the showMessagePopup function.
 */
var dialog_close = {
    width: '16px', 
    height: '16px',
    background: 'transparent url(/static/images/close.gif) no-repeat',
    position: 'absolute',
    top: '6px',
    right: '7px' 
};

var Gloss = {
    position: 'absolute',
    'z-index': '1000',
    'padding-top': '10px'
};

function quickViewGlossaryTerm(html, glossaryTerm, locale, colFlag){
    var oDiv;
    var uiCtrl;
    var uiChildCtrl;
    var index,ctrlCount, className;
    var divName;
    divName = "div_" + glossaryTerm + "_" + locale;
    var gDiv = $("div#" + divName);
    oDiv = document.getElementById("glossaryTerms");
    
    $('#Gloss').remove();
    if (colFlag == 'col2') {
        xCoord = xCoord -390;
    }
    if (colFlag == '') {
        var linkId = glossaryTerm;
        var de = document.documentElement;
        var w = self.innerWidth || (de&&de.clientWidth) || document.body.clientWidth;
        var hasArea = w - getAbsoluteLeft(linkId);
        var clickElementy = getAbsoluteTop(linkId) - 3; //set y position
        var arrowOffset = getElementWidth(linkId);
        if(hasArea>(425)){
            var clickElementx = getAbsoluteLeft(linkId) + arrowOffset; //set x position
        } else {
            var clickElementx = getAbsoluteLeft(linkId) + 25; //set x position
        }
        $("body").append("<div id='Gloss' style='width:350px;'class='hovertip view'></div>");//right side
        $('#Gloss').css({left: clickElementx+"px", top: clickElementy+"px"}).css(Gloss);
        $('#Gloss').show();
        $('#Gloss').html(html);
        $('#dialog_close_' + glossaryTerm, $('#Gloss')).click(function () { $('#Gloss').remove(); }).css(dialog_close);
        secondLink = linkId;
        links.push(linkId);
    } else {
        var divs = document.getElementsByTagName('div');
        for(var i = 0;i < divs.length; i++) {
            if (divs[i].className == 'hovertip' && divs[i].id != divName) {
                $('div#' + divs[i].id).html('');
                $('div#' + divs[i].id).removeClass('hovertip');
            }
        }
    gDiv.css({
              'position':'absolute',
              //START:10.1.1:INC000000206989:Glossary sub-cat UI issue
              'top': (yCoord -292) + 'px',
              'left': (xCoord -21) + 'px',
              //END:10.1.1:INC000000206989:Glossary sub-cat UI issue
              'width':'350px'})
            .show();
        gDiv.addClass('hovertip');
        gDiv.html(html);
        $('#dialog_close_' + glossaryTerm, gDiv).click(function () { gDiv.hide(); $('#Gloss').remove(); }).css(dialog_close);
        gDiv.show();
    }
}

function glossaryTermError(xmlHttpRequest, status, exception) {
    $("div#glossaryTerms").html("Error in loading the glossary Terms");
}

function getElementWidth(objectId) {
    var x = document.getElementById(objectId);
    if (x == undefined) {
        x = document.getElementById(secondLink);
        for (i=links.length-1;i>=0;i--) {
            if (x == undefined) {
                x = document.getElementById(links[i]);
            } else {
                break;
            }
        }
    }
    var frag = document.createDocumentFragment(); 
     var p1=document.createElement('DIV');
     var p2=document.createElement('DIV');
     p2.style.visibility='hidden';
     p1.style.width=x.style.width;
     p1.style.height=x.style.height;
     p2.style.position='absolute';
     p1.style.position='relative';
     p1.innerHTML=x.innerHTML;
     document.body.appendChild(p2);
     p2.appendChild(p1);
     var w=p1.offsetWidth;
     document.body.removeChild(p2);
     return w;  
}

function getAbsoluteLeft(objectId) {
    // Get an object left position from the upper left viewport corner
    var o = document.getElementById(objectId);
    if (o == undefined) {
        o = document.getElementById(secondLink);
        for (i=links.length-1;i>=0;i--) {
            if (o == undefined) {
                o = document.getElementById(links[i]);
            } else {
                break;
            }
        }
    }
    var oLeft = o.offsetLeft;            // Get left position from the parent object
    while(o.offsetParent!=null) {   // Parse the parent hierarchy up to the document element
        var oParent = o.offsetParent;    // Get parent object reference
        oLeft += oParent.offsetLeft; // Add parent left position
        o = oParent;
    }
    return oLeft;
}

function getAbsoluteTop(objectId) {
    // Get an object top position from the upper left viewport corner
    var o = document.getElementById(objectId);
    if ((o == undefined) || (o.style.display == 'none')) {
        o = document.getElementById(secondLink);
        for (i=links.length-1;i>=0;i--) {
            if (o == undefined) {
                o = document.getElementById(links[i]);
            } else {
                break;
            }
        }
    }
    var oTop = o.offsetTop;            // Get top position from the parent object
    while(o.offsetParent!=null) { // Parse the parent hierarchy up to the document element
        var oParent = o.offsetParent;  // Get parent object reference
        oTop += oParent.offsetTop; // Add parent top position
        o = oParent;
    }
    return oTop;
}
/* End Modification for Glossary changes - 9.2.2 */
/* End: Glossary of term*/

/* Start Release 9.4.1: product change notification(PCN) implementation */
function divShowHide(divId) {
    var oDiv;
    var uiCtrl;
    var uiLiCtrl;
    var uiChildCtrl;
    var uiDivCtrl;
    var index,index1,ctrlCount,liCtrlCount;

    oDiv = document.getElementById(divId);

    if(oDiv.className == "divhidestyle"){
      oDiv.className = "divdisplaystyle";
    } else {
      oDiv.className = "divhidestyle";
    }

    uiLiCtrl = oDiv.parentNode;
    uiCtrl = uiLiCtrl.parentNode;
    ctrlCount = uiCtrl.childNodes.length;

    for (index=0;index<ctrlCount;index++){
        uiChildCtrl = uiCtrl.childNodes[index];
        if (uiChildCtrl.tagName == 'LI' ){
             liCtrlCount = uiChildCtrl.childNodes.length;
             for (index1=0;index1<liCtrlCount;index1++){
                uiDivCtrl = uiChildCtrl.childNodes[index1];
                if (uiDivCtrl.tagName == 'DIV' && uiDivCtrl.id != divId && uiDivCtrl.className != "divhidestyle" && uiDivCtrl.id != "div1"){
                    uiDivCtrl.className = "divhidestyle";
                }
            }
        }
    }
}

/* Start Release 9.4.2: PCN implementation - myAnalog Subscription*/
/* Start Release 9.4.2: PCN implementation - myAnalog Subscription*/
function loadPopupTitleForPCN() {

   	var descDiv;
   	var modelDiv;
   	var modelId;
   	var desc;
   	var h1Text;
	var h1TextNode;
	var h1SpanText;
	var newspanelement;
	var cCont;
   
   	modelDiv = document.getElementById('model_number');
   	modelId = modelDiv.innerHTML;    	
   	descDiv = document.getElementById('product_desc');
   	desc = descDiv.innerHTML;
  	h1Text = modelId + ":  " ;
    h1TextNode = document.createTextNode(h1Text);
   	h1SpanText = desc.trim().toUpperCase();
    newspanelement = document.createElement("span");
    newspanelement.innerHTML = h1SpanText;
    cCont = document.getElementsByTagName("h1")[0];
    cCont.appendChild(h1TextNode);
    cCont.appendChild(newspanelement);
    
}
/* End Release 9.4.2: PCN implementation - myAnalog Subscription*/
/* End Release 9.4.2: PCN implementation - myAnalog Subscription*/
/* End Release 9.4.1:  product change notification(PCN) implementation */

/* Start Release 9.4.1:  Features And Specifications Tab Functionality */
function hideFeaturesHeading(key)
{
	if(document.getElementById('spec_blue')!=null &&
		 document.getElementById('spec_white')!==null &&
		 document.getElementById('feature_blue')!==null &&
		 document.getElementById('feature_white')!==null)
	{
		if(key=='spec')
		{
			document.getElementById('spec_blue').style.display = "none";
			document.getElementById('spec_white').style.display = "block";
			document.getElementById('feature_blue').style.display = "block";
			document.getElementById('feature_white').style.display = "none";
		}
		else if(key=='feature')
		{
			document.getElementById('spec_blue').style.display = "block";
			document.getElementById('spec_white').style.display = "none";
			document.getElementById('feature_blue').style.display = "none";
			document.getElementById('feature_white').style.display = "block";
		}
	}	
}
/* End Release 9.4.1:  Features And Specifications Tab Functionality */
var iframeFlag=true;
function fnShowMsg() 
{
	//$("span#waitMessage").show();
	//$("span#waitMessage").toggle();	
	window.setTimeout('showProgress()', 1);
	$("div#podsSectionsDisplay").hide();
	$("div#podsSectionsDisplay1").hide();
	$("div#product_category_drop").hide();
	$("div#rAndTCatDropDownIframeDiv").hide();
	$("span#noResults").hide();
	$("div#selectedDetails").hide();
	$("div#resourceListingDiv").hide();	
	// 10.1.2 Issue#509 Start
	$("span#RandTBlueBox").hide();
	// 10.1.2 Issue#509 end
	iframeFlag=false;
	return true;
}

function showHideIframe(divId,mode)
{	
	if(document.getElementById(divId).style.display!=mode && iframeFlag==true)
	{
		document.getElementById(divId).style.display = mode;
	}
}

function showProgress()
{	
	document.getElementById('waitMessage').style.display='block'; 
}

function fnAssignDateSheetLink()
{
	if(document.getElementById('transDataSheetLink1')!=null && document.getElementById('transDataSheetLink1').href!='')
	{
		window.open(document.getElementById('transDataSheetLink1').href,'dataSheetHelp','toolbar=0,scrollbars=yes,location=0,statusbar=0,menubar=1,resizable=1,width=690,height=600');
		return false;
	}
	else if(document.getElementById('transDataSheetLink0')!=null && document.getElementById('transDataSheetLink0').href!='')
	{
		document.getElementById('pdfIconLink').href =  document.getElementById('transDataSheetLink0').href;
		return true;
	}
	else if(document.getElementById('enDataSheetLink')!=null  && document.getElementById('enDataSheetLink').href!='')
	{
		document.getElementById('pdfIconLink').href =  document.getElementById('enDataSheetLink').href;
		return true;
	}
	else
		return false;
}


//touch 1
/* Added for FAQs */
function toggle(less,more)
{
   	document.getElementById(less).style.display = 'none';
   	document.getElementById(more).style.display = 'block';
   	$("div#" + more).css("margin-left", "4px");
}

function toggle_listing(less,more)
{
   	document.getElementById(less).style.display = 'none';
   	document.getElementById(more).style.display = 'block';
   	$("div#" + more).css("margin-left", "6px");
   	$("div#" + more).css("margin-top", "10px");   	
}

/* Start Release 10.1.1: Special character handling in PCN model id */
/* Function to open PCN popup in a new window*/
function openPCNPopup(url, modelId){
	if (url != null && modelId != null) {
		modelId = encodeURIComponent(modelId);
		url += '&modelId=' + modelId;		
		//alert(url);
		window.open(url,'product_title','toolbar=0,scrollbars=yes,location=0,statusbar=0,menubar=1,resizable=1,width=690,height=600');
	}
}
/* End Release 10.1.1: Special character handling in PCN model id */

/* START: Addition for Microsites-2 Issue#17 */
function equalizeSubBand(renderedsubBandCount) {
	if (renderedsubBandCount != null && renderedsubBandCount != undefined) {
		var sugSecDiv = $('div.suggested_sec');
		if (sugSecDiv != undefined) {
			var ind;
			var index;
			for (ind=0; ind<sugSecDiv.length; ind++) {
				var maxHeightPod = 0;
				
				var childCount = sugSecDiv[ind].childNodes.length;
				for (index=0; index<childCount; index++) {
					var childElmnt = sugSecDiv[ind].childNodes[index];
			        if (childElmnt != null) {
				        if (childElmnt.className == "explore_application") {
				        	var tmpHeight = $(childElmnt).height();
				            maxHeightPod = (tmpHeight > maxHeightPod) ? tmpHeight : maxHeightPod;
				        } 
			        }
				}
				
				for (index=0; index<childCount; index++) {
					var childElmnt = sugSecDiv[ind].childNodes[index];
			        if (childElmnt != null) {
			        	if (childElmnt.className == "explore_application") {
				            $(childElmnt).height(maxHeightPod);
				        }
			        }
				}
			}
		}
	}
}	
/* END: Addition for Microsites-2 Issue#17 */
	
