/******************************************************************************************************
 * Mod Log
 * Version  Author             Date             Description
 * 1.0      Pratyusha Ghosh    Sep 05, 2009     Script file for addthis 'Share' button functionality
 *                                              incorporating IE6 "select" control fix.
******************************************************************************************************/
	var addthis_iframe;
	var body = document.getElementsByTagName('body')[0];
	var addthis_div = 'at15s';
	
	function addthis_show(link) {
	   var return_val = addthis_open(link, '', '[URL]', '[TITLE]');
	   
	   var target = document.getElementById(addthis_div);
	   if (target !== 'undefined' && target !== null) {
		   target.onmouseout = function() {
		      addthis_hide();
		   };
	   }
	   createIframe(target);
	            
	   return return_val;
	}
	
	function addthis_hide() {
	   setTimeout('removeIframe()', 510);
	   addthis_close();
	}
	
	function createIframe(target) {
	   if ($.browser.msie && parseInt($.browser.version) <= 6) {  //test for MSIE 6.x;
	     addthis_iframe = document.getElementById('addthis_blocker');
	     if (!addthis_iframe) {
	        addthis_iframe = document.createElement('iframe');
	        addthis_iframe.setAttribute('id', 'addthis_blocker');
	        addthis_iframe.setAttribute('frameborder', '0');
	        addthis_iframe.setAttribute('src', 'javascript:"<html></html>;"');
	        addthis_iframe.style.position = 'absolute';
	        addthis_iframe.style.top = target.offsetTop + 'px';
	        addthis_iframe.style.left = target.offsetLeft + 'px';
	        addthis_iframe.style.width = target.offsetWidth + 'px';
	        addthis_iframe.style.height = target.offsetHeight + 'px';
	        
	        body.appendChild(addthis_iframe);
	     }
	   }
	}
	
	function removeIframe() {
	   var target = document.getElementById(addthis_div);	   
	   addthis_iframe = document.getElementById('addthis_blocker');
	   
	   if ((target.style.display == 'none') && (addthis_iframe)) {
	      body.removeChild(addthis_iframe);
	   }   
	}
