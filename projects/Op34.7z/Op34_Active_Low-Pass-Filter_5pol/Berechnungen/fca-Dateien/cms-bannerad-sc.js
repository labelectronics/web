function loadSectionContentImages(locale,sectionName, bheight, bwidth) {	
	var pageURL = location.href;
	var taxonomyType;
	
	if ((pageURL.indexOf("/products") > -1) || (pageURL.indexOf("/processors") > -1))
		taxonomyType = "products";
	else if (pageURL.indexOf("/applications") > -1)
		taxonomyType = "applications";
	else if (pageURL.indexOf("/functions") > -1)
		taxonomyType = "functions";
	else if (pageURL.indexOf("/design-center-dsp") > -1)
		taxonomyType = "design-center-dsp";
	else if (pageURL.indexOf("/design-center") > -1)
		taxonomyType = "design-center";
	else if (pageURL.indexOf("/headlines") > -1)
		taxonomyType = "headlines";
	else if (pageURL.indexOf("/content") > -1)
		taxonomyType = "content";
	else if (pageURL.indexOf("/packages") > -1)
		taxonomyType = "packages";
	else if (pageURL.indexOf("/resources") > -1)
		taxonomyType = "resources";
	else if (pageURL.indexOf("/technical-background") > -1)
		taxonomyType = "technical-background";
	
	getSectionContentImages(locale,sectionName,taxonomyType, bheight, bwidth );
	
}

function getSectionContentImages(locale,sectionName,taxonomyType, bheight, bwidth) {
	$.ajax({
		type: "GET",
		url: "/" + locale + "/" + sectionName + "/" + taxonomyType + "/sectioncontent/images.html",
		timeout: 10000,
		success: function(xml) {
			displaySectionContentImages(xml, bheight, bwidth)
		},
		error: displaySectionContentImageError,
		dataType: "xml"
	});
}

function displaySectionContentImageError(xhr, status, e) {
	
	$("div#banner-ad-promo").html("Error in Loading banner image");
	ajaxCount = ajaxCount - 1;
}

function displaySectionContentImages(xml, bheight, bwidth){	
	var actualHeight=bheight;
	var actualWidth=bwidth;	
	var strStatic="/static";
	$("div#banner-ad-promo").html("Loading banner image");

	var promoBannerCount = 0;
	var bannerImageHtml = "";
	var fSlash = "/";
	$("SectionContentImages/PromoImage/Image", xml).each(function() {
		promoBannerCount+=1;
	});
	var randomNumber = Math.random();
	var rand = Math.round((promoBannerCount-1)* randomNumber);
	var i=0;
	$("SectionContentImages/PromoImage/Image", xml).each(function() {
		if (i==rand){
			var imgUrl = $("URL",this).text();
			var hburl = imgUrl.replace(/\\/g, fSlash);
			var bannerlinkurl = $("ImgLinkURL",this).text();
			var searchFor = "www.analog.com";
			var index = bannerlinkurl.indexOf(searchFor);
			var target;
			if(index != -1) {
				target = "_self";
			} else {
				target = "_blank";
			}

			var flashIndex = hburl.indexOf(".swf") || hburl.indexOf(".fla");
			if (flashIndex != -1) {
				// display flash file
				bannerImageHtml += "<object><embed src=\"" + strStatic + hburl + "\"></embed></object>";
			} else {
				// display background images with overlay text
				var overlayText = $("OverlayText",this).text();
				if (overlayText != "null") {
					// display the overlay text: The UI specification such as width, height, font styles are hardcoded time-being, need to revisit the according to Site Redesign requirements (Jun-09-2009)
					bannerImageHtml += "<div id=\"banner-ad-promo\" style=\"background:#FFFFFF url("+ strStatic + hburl +") repeat-x scroll left top; height:100px; width:805px; font-size:12px; font-color:#FFFFFF font-family:'Arial','Verdana','Helvetica',sans-serif;\">";
					bannerImageHtml += "<span>" + overlayText + "</span>";
					bannerImageHtml += "</div>";
				} else if (bannerlinkurl != "null") {
					// display banner ad images with link to an URL
					bannerImageHtml += "<a href=\"" + bannerlinkurl + "\" target=\"" + target + "\">";
					bannerImageHtml += "<img src=\"" + strStatic + hburl + "\" alt=\"" + $("AltText",this).text()+ "\"/>";
					bannerImageHtml += "</a>";
				} else {
					// display banner ad images without any URL links
					bannerImageHtml += "<img src=\"" + strStatic + hburl + "\" alt=\"" + $("AltText",this).text()+ "\"/>";
				}
			}
		}
		i+=1;
	});
	$("div#banner-ad-promo").html(bannerImageHtml);

	$("div#banner-ad-quotes").html("Loading ad image");

	var adImageCount = 0;
	var adImageHtml = "";
	$("SectionContentImages/QuoteImage/Image", xml).each(function() {
		adImageCount+=1;
	});
	var randomNumber1 = Math.random();
	var rand1 = Math.round((adImageCount-1) * randomNumber);
	var j=0;			
	$("SectionContentImages/QuoteImage/Image", xml).each(function() {
		if (j==rand1){
			var imgUrl = $("URL",this).text();
			var adurl = imgUrl.replace(/\\/g, fSlash);
			var adlinkurl = $("ImgLinkURL",this).text();
			var searchForInAdLink = "www.analog.com";
			var indexInAdLink = adlinkurl.indexOf(searchForInAdLink);
			var targetForAdLink;
			if(indexInAdLink != -1) {
				targetForAdLink = "_self";
			} else {
				targetForAdLink = "_blank";
			}

			var flashIndex = adurl.indexOf(".swf") || adurl.indexOf(".fla");
			if (flashIndex != -1) {
				// display flash file
				if(actualHeight != '' && actualWidth !=''){					
					adImageHtml += "<object><embed src=\"" + strStatic + adurl + "\"  height=\"" + actualHeight + "\" width=\"" +actualWidth +"\" quality=\"high\" wmode=\"opaque\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\"></embed></object>";
				}else{
					adImageHtml += "<object><embed src=\"" + strStatic + adurl + "\"   quality=\"high\" wmode=\"opaque\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\"></embed></object>";
				}
			} else {
				// display background images with overlay text
				var overlayText = $("OverlayText",this).text();
				if (overlayText != "null") {
					// display the overlay text: The UI specification such as width, height, font styles are hardcoded time-being, need to revisit the according to Site Redesign requirements (Jun-09-2009)
					adImageHtml += "<div id=\"banner-ad-quotes\" style=\"background:#FFFFFF url("+ strStatic + adurl +") repeat-x scroll left top; height:100px; width:805px; font-size:12px; font-color:#FFFFFF font-family:'Arial','Verdana','Helvetica',sans-serif;\">";
					adImageHtml += "<span>" + overlayText + "</span>";
					adImageHtml += "</div>";
				} else if (adlinkurl != "null") {
					// display ad images with link to an URL
					adImageHtml += "<a href=\"" + adlinkurl + "\" target=\"" + targetForAdLink + "\">";
					adImageHtml += "<img src=\"" + strStatic + adurl + "\" alt=\"" + $("AltText",this).text()+ "\"/>";
					adImageHtml += "</a>";
				} else {
					// display banner ad images without any URL links
					var myMap = "#Map";
					adImageHtml += "<img src=\"" + strStatic + adurl + "\"  USEMAP=\"" +myMap + "\"  alt=\"" + $("AltText",this).text()+ "\"/>";					
				}
			}
		}
		j+=1;
	});
	$("div#banner-ad-quotes").html(adImageHtml);
	ajaxCount = ajaxCount - 1;
}
//touch 1