var currentIndex = 0;
var previousIndex = 0;
var runningCurrIndex = 0;
var indexFlag = false;
var timeOut = 10000;
var timer ;
var pauseOrPlay = true;
var testimonialArray;
var msgCat;

function loadTestimonialItems(locale,sectionName) {
	var taxonomyType;
	var pageURL = location.href;
	if ((pageURL.indexOf("/processors") > -1) || (pageURL.indexOf("/products") > -1)) {
		taxonomyType = "products";
	}	
	else if (pageURL.indexOf("/content") > -1) {
		taxonomyType = "content";
	}
	
	$.ajax({
		type: "GET",
		url: "/" + locale + "/" + sectionName + "/" + taxonomyType + "/resources/testimonial.html",
		timeout: 10000,
		success: function(xml) {
			buildTestimonials(xml)
		},
		error: displayTestimonialsError,
		dataType: "xml"
	});
}

function displayTestimonialsError(xmlHttpRequest, status, exception) {
	$('div#testimonialContent').html("Error in loading data");
}

function buildTestimonials(xml){
	var strStatic="/static";
	var testimonialBodyHtml;
	var allTestimonial = $("Testimonials/Testimonial", xml);
	var noOfTestimonial = allTestimonial.length;
	
	testimonialArray = new Array(noOfTestimonial);
	
	var testimonialHtml = "";
	if (noOfTestimonial > 0) {
		testimonialHtml = testimonialHtml.concat("<tr style='line-height: 13px;'>");
		if (noOfTestimonial > 1) {
			
			testimonialHtml = testimonialHtml.concat("<td width='80px;' style='padding: 0px;'><img src=\"/static/images/org_arrow_lf.gif\" alt=\"Arrow\" style='padding-right:5px;'/>");
			testimonialHtml = testimonialHtml.concat("<a style='text-decoration:none;' href='#' onClick='showPrevDynaContent();return false'>" + msgCat['verifiedCircuits.Master.Pagination.Previous'] + "</a></td>");
			for (j=0; j< noOfTestimonial; j++) {
				if(j>0) {
				testimonialHtml = testimonialHtml.concat("<td width='10px;' style='padding: 0px;'><img src=\"/static/images/seperator_bg.gif\" alt=\"Arrow\"'/></td>");
				testimonialHtml = testimonialHtml.concat("<td width='20px;' style='padding: 0px;'><a style='text-decoration:none;' id='slide" + j + "' href='#' onClick='showNumberedDynaContent(" + j + ");return false'>" + (j+1) + "</a></td>");
				} else {
				testimonialHtml = testimonialHtml.concat("<td width='20px;' style='padding: 0px;'><a  style='text-decoration:none;' id='slide" + j + "' href='#' onClick='showNumberedDynaContent(" + j + ");return false'>" + (j+1) + "</a></td>");
				}
			}
			testimonialHtml = testimonialHtml.concat("<td width='80px;' style='padding: 0px;'><a style='text-decoration:none;' href='#' onClick='showNextDynaContent();return false'>" + msgCat['verifiedCircuits.Master.Pagination.Next'] + "</a>");
			testimonialHtml = testimonialHtml.concat("<img src=\"/static/images/org_arrow_rt.gif\" alt=\"Arrow\" style='padding-left:5px;'/></td>");
			testimonialHtml = testimonialHtml.concat("<td width='250px;' style='padding: 0px;'>&nbsp;&nbsp;&nbsp;&nbsp;<a href='#' onClick='pauseOrPlayDynaContent();return false'><img style='padding-top:2px;' id='playPause' src=\"/static/images/play1.gif\" /></a></td>");
		}
		testimonialHtml = testimonialHtml.concat("</tr>");
	}
	//alert('testimonialHtml --> ' + testimonialHtml);
	for( i = 0; i < noOfTestimonial; i++) {
		
		var testimonial = allTestimonial.get(i);
		
		//fetching the data related to testimonials
		var name = $("Name",testimonial).text();
		var role = $("Role",testimonial).text();
		var description = $("Description",testimonial).text();
		var moreLink = $("Morelink",testimonial).text();
		var imagePath = $("ImagePath",testimonial).text();
		var imageAltPath = $("ImageAltPath",testimonial).text();
		
		//forming the html content
		testimonialBodyHtml = "";
		
		if(imagePath != "null" && imagePath != "") {
			testimonialBodyHtml = testimonialBodyHtml.concat("<img src=\"" + strStatic + imagePath + "\" alt=\"" + imageAltPath + "\" /><br/><br/>");
		}
		
		if(description != "null" && description != "") {
			testimonialBodyHtml = testimonialBodyHtml.concat(description);
		}
		
		if(moreLink != "null" && moreLink != "") {
			/*testimonialBodyHtml = testimonialBodyHtml.concat("<img src=\"" + strStatic + "/images/org_arrow_rt.gif\" alt=\"Arrow\" />");
			testimonialBodyHtml = testimonialBodyHtml.concat("<a href=\"" + moreLink + "\" target='_blank'>More...</a>");*/
			testimonialBodyHtml = testimonialBodyHtml.concat("<div style='float: right'><span").concat(  
			        " style='text-align: right;padding-right: 12px;background: url(").concat(
			        "/static/images/right_arrow_bullet.gif) no-repeat scroll right'><a href='").concat(
			         moreLink + "' target='_blank'>" + msgCat['verifiedCircuits.Master.More'] + "</a></span></div>");
		}
		testimonialArray[i] = testimonialBodyHtml;
	}
	if (noOfTestimonial > 0) {
	$('table#testimonial').html(testimonialHtml);
	$('a#slide0').addClass('selectedNum');
	$('div#testimonialContent').html(testimonialArray[0]);
	$('div#testimonialContent').addClass('testimonialStyle');
	}
	if (noOfTestimonial > 1) {
		$('div#testimonialContent').mousedown(function(event){
			pauseDynaContent(event);
		});
		rotateContent();
	}
}

function rotateContent(){
	if (document.all || document.getElementById){
		timer = setInterval("loopCount()", timeOut);
	}
}

function loopCount(){
	currentIndex = (currentIndex < testimonialArray.length-1 ) ? currentIndex+1 : 0;
	previousIndex = (currentIndex == 0) ? testimonialArray.length-1 : currentIndex-1;
	displayTestimonialContent();
}

function displayTestimonialContent() {
	var content = $('div#testimonialContent');
	content.hide();
	content.html(testimonialArray[currentIndex]);
	if (indexFlag == true) {
		$('a#slide' + (runningCurrIndex)).removeClass('selectedNum');
		indexFlag = false;
	}
	if (currentIndex > 0) {
		$('a#slide' + (currentIndex-1)).removeClass('selectedNum');
		$('a#slide' + (currentIndex)).addClass('selectedNum');
	} else {
		$('a#slide' + (testimonialArray.length-1)).removeClass('selectedNum');
		$('a#slide0').addClass('selectedNum');
	}		
	content.show();
}

function showNumberedDynaContent(slideNum){
	runningCurrIndex = currentIndex;
	indexFlag = true;
	currentIndex = slideNum;
	if (slideNum == 0) {
		previousIndex = testimonialArray.length -1;
	} else {
		previousIndex = slideNum - 1;
	}
	displayTestimonialContent();
	clearInterval(timer);
	if(pauseOrPlay){
	rotateContent();
	}
}

function showPrevDynaContent(){
	runningCurrIndex = currentIndex;
	indexFlag = true;
	currentIndex = (currentIndex == 0) ? testimonialArray.length-1 : currentIndex-1;
	previousIndex = (currentIndex < testimonialArray.length-1 ) ? currentIndex+1 : 0;
	displayTestimonialContent();
	clearInterval(timer);
	if(pauseOrPlay){
	rotateContent();
	}
}

function showNextDynaContent(){
	currentIndex = (currentIndex < testimonialArray.length-1 ) ? currentIndex+1 : 0;
	previousIndex = (currentIndex == 0) ? testimonialArray.length-1 : currentIndex-1;
	displayTestimonialContent();
	clearInterval(timer);
	if(pauseOrPlay){
	rotateContent();
	}
}

function pauseOrPlayDynaContent (){
		if (pauseOrPlay == true){
			clearInterval(timer);
			pauseOrPlay = false;
			$("img#playPause").addClass('playPauseImage');
		}else {
			pauseOrPlay = true;
			$("img#playPause").removeClass('playPauseImage');
			displayTestimonialContent();
			rotateContent ();
		}	
}

function pauseDynaContent (event){
		if (pauseOrPlay == true){
			var button;
			if (event.which == null) {
				button= (event.button < 2) ? "LEFT" :((event.button == 4) ? "MIDDLE" : "RIGHT");
			}else {
				button= (event.which < 2) ? "LEFT" : ((event.which == 2) ? "MIDDLE" : "RIGHT");
			}

			if(button == "LEFT") {
				clearInterval(timer);
				pauseOrPlay = false;
				$("img#playPause").addClass('playPauseImage');
			}
		}
}

//touch 1